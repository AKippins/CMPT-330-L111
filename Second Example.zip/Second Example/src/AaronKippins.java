import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;


public class AaronKippins extends JFrame {

	private JPanel contentPane;
	private final JLabel lblCmptRulez = new JLabel("CMPT330 Rulez!");
	private final JButton btnFancy = new JButton("Fancy");
	private final JButton btnFancier = new JButton("Fancier");
	private final JLabel lblSoDoesDmb = new JLabel("So Does DMB!");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AaronKippins frame = new AaronKippins();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AaronKippins() {
		jbInit();
	}
	private void jbInit() {
		setTitle("Aaron Kippins");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblCmptRulez.setForeground(Color.BLUE);
		lblCmptRulez.setFont(new Font("Old English Text MT", Font.PLAIN, 25));
		lblCmptRulez.setBounds(97, 30, 214, 32);
		
		contentPane.add(lblCmptRulez);
		btnFancy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_btnFancy_actionPerformed(arg0);
			}
		});
		btnFancy.setBounds(163, 147, 89, 23);
		
		contentPane.add(btnFancy);
		btnFancier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnFancier_actionPerformed(e);
			}
		});
		btnFancier.setBounds(163, 206, 89, 23);
		
		contentPane.add(btnFancier);
		lblSoDoesDmb.setForeground(Color.PINK);
		lblSoDoesDmb.setFont(new Font("Broadway", Font.PLAIN, 25));
		lblSoDoesDmb.setBounds(107, 73, 193, 36);
		lblSoDoesDmb.setVisible(false);
		
		contentPane.add(lblSoDoesDmb);
	}
	protected void do_btnFancy_actionPerformed(ActionEvent arg0) {
		lblCmptRulez.setVisible(!(lblCmptRulez.isVisible()));
	}
	protected void do_btnFancier_actionPerformed(ActionEvent e) {
		lblCmptRulez.setVisible(!(lblCmptRulez.isVisible()));
		lblSoDoesDmb.setVisible(!(lblSoDoesDmb.isVisible()));
	}
}
