import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Groups extends JFrame {

	private JPanel contentPane;
	private final JRadioButton rdbtnOne = new JRadioButton("One");
	private final JRadioButton rdbtnTwo = new JRadioButton("Two");
	private final JRadioButton rdbtnThree = new JRadioButton("Three");
	private final JRadioButton rdbtnFour = new JRadioButton("Four");
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final JCheckBox chckbxFirst = new JCheckBox("First");
	private final JCheckBox chckbxSecond = new JCheckBox("Second");
	private final JCheckBox chckbxThird = new JCheckBox("Third");
	private final JLabel lblRadioChoice = new JLabel("Radio Choice:");
	private final JLabel lblCheckboxChoices = new JLabel("Checkbox Choice(s):");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Groups frame = new Groups();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Groups() {
		jbInit();
	}
	private void jbInit() {
		setTitle("Aaron Kippins");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		buttonGroup.add(rdbtnOne);
		rdbtnOne.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnOne_actionPerformed(e);
			}
		});
		rdbtnOne.setBounds(36, 60, 109, 23);
		
		contentPane.add(rdbtnOne);
		buttonGroup.add(rdbtnTwo);
		rdbtnTwo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnTwo_actionPerformed(e);
			}
		});
		rdbtnTwo.setBounds(36, 86, 109, 23);
		
		contentPane.add(rdbtnTwo);
		buttonGroup.add(rdbtnThree);
		rdbtnThree.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnThree_actionPerformed(e);
			}
		});
		rdbtnThree.setBounds(36, 112, 109, 23);
		
		contentPane.add(rdbtnThree);
		buttonGroup.add(rdbtnFour);
		rdbtnFour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnFour_actionPerformed(e);
			}
		});
		rdbtnFour.setBounds(36, 136, 109, 23);
		
		contentPane.add(rdbtnFour);
		chckbxFirst.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxFirst_actionPerformed(e);
			}
		});
		chckbxFirst.setBounds(181, 60, 97, 23);
		
		contentPane.add(chckbxFirst);
		chckbxSecond.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxSecond_actionPerformed(e);
			}
		});
		chckbxSecond.setBounds(181, 86, 97, 23);
		
		contentPane.add(chckbxSecond);
		chckbxThird.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxThird_actionPerformed(e);
			}
		});
		chckbxThird.setBounds(181, 112, 97, 23);
		
		contentPane.add(chckbxThird);
		lblRadioChoice.setBounds(36, 39, 135, 14);
		
		contentPane.add(lblRadioChoice);
		lblCheckboxChoices.setBounds(181, 39, 243, 14);
		
		contentPane.add(lblCheckboxChoices);
	}
	
	protected void do_chckbxFirst_actionPerformed(ActionEvent e) {
		if(chckbxFirst.isSelected() && chckbxSecond.isSelected() && chckbxThird.isSelected()){
			lblCheckboxChoices.setText("Checkbox Choice(s): First, Second, Third");
		}
		if(chckbxFirst.isSelected() && chckbxSecond.isSelected() && (!(chckbxThird.isSelected()))){
			lblCheckboxChoices.setText("Checkbox Choice(s): First, Second");
		}
		if((!(chckbxFirst.isSelected())) && chckbxSecond.isSelected() && chckbxThird.isSelected()){
			lblCheckboxChoices.setText("Checkbox Choice(s): Second, Third");
		}
		if(chckbxFirst.isSelected() && (!(chckbxSecond.isSelected())) && chckbxThird.isSelected()){
			lblCheckboxChoices.setText("Checkbox Choice(s): First, Third");
		}
		if(chckbxFirst.isSelected() && (!(chckbxSecond.isSelected())) && (!(chckbxThird.isSelected()))){
			lblCheckboxChoices.setText("Checkbox Choice(s): First");
		}
		if((!(chckbxFirst.isSelected())) && chckbxSecond.isSelected() && (!(chckbxThird.isSelected()))){
			lblCheckboxChoices.setText("Checkbox Choice(s): Second");
		}
		if((!(chckbxFirst.isSelected())) && (!(chckbxSecond.isSelected())) && chckbxThird.isSelected()){
			lblCheckboxChoices.setText("Checkbox Choice(s): Third");
		}
		if((!(chckbxFirst.isSelected())) && (!(chckbxSecond.isSelected())) && (!(chckbxThird.isSelected()))){
			lblCheckboxChoices.setText("Checkbox Choice(s):");
		}
		
	}
	protected void do_chckbxSecond_actionPerformed(ActionEvent e) {
		if(chckbxFirst.isSelected() && chckbxSecond.isSelected() && chckbxThird.isSelected()){
			lblCheckboxChoices.setText("Checkbox Choice(s): First, Second, Third");
		}
		if(chckbxFirst.isSelected() && chckbxSecond.isSelected() && (!(chckbxThird.isSelected()))){
			lblCheckboxChoices.setText("Checkbox Choice(s): First, Second");
		}
		if((!(chckbxFirst.isSelected())) && chckbxSecond.isSelected() && chckbxThird.isSelected()){
			lblCheckboxChoices.setText("Checkbox Choice(s): Second, Third");
		}
		if(chckbxFirst.isSelected() && (!(chckbxSecond.isSelected())) && chckbxThird.isSelected()){
			lblCheckboxChoices.setText("Checkbox Choice(s): First, Third");
		}
		if(chckbxFirst.isSelected() && (!(chckbxSecond.isSelected())) && (!(chckbxThird.isSelected()))){
			lblCheckboxChoices.setText("Checkbox Choice(s): First");
		}
		if((!(chckbxFirst.isSelected())) && chckbxSecond.isSelected() && (!(chckbxThird.isSelected()))){
			lblCheckboxChoices.setText("Checkbox Choice(s): Second");
		}
		if((!(chckbxFirst.isSelected())) && (!(chckbxSecond.isSelected())) && chckbxThird.isSelected()){
			lblCheckboxChoices.setText("Checkbox Choice(s): Third");
		}
		if((!(chckbxFirst.isSelected())) && (!(chckbxSecond.isSelected())) && (!(chckbxThird.isSelected()))){
			lblCheckboxChoices.setText("Checkbox Choice(s):");
		}
	}
	protected void do_chckbxThird_actionPerformed(ActionEvent e) {
		if(chckbxFirst.isSelected() && chckbxSecond.isSelected() && chckbxThird.isSelected()){
			lblCheckboxChoices.setText("Checkbox Choice(s): First, Second, Third");
		}
		if(chckbxFirst.isSelected() && chckbxSecond.isSelected() && (!(chckbxThird.isSelected()))){
			lblCheckboxChoices.setText("Checkbox Choice(s): First, Second");
		}
		if((!(chckbxFirst.isSelected())) && chckbxSecond.isSelected() && chckbxThird.isSelected()){
			lblCheckboxChoices.setText("Checkbox Choice(s): Second, Third");
		}
		if(chckbxFirst.isSelected() && (!(chckbxSecond.isSelected())) && chckbxThird.isSelected()){
			lblCheckboxChoices.setText("Checkbox Choice(s): First, Third");
		}
		if(chckbxFirst.isSelected() && (!(chckbxSecond.isSelected())) && (!(chckbxThird.isSelected()))){
			lblCheckboxChoices.setText("Checkbox Choice(s): First");
		}
		if((!(chckbxFirst.isSelected())) && chckbxSecond.isSelected() && (!(chckbxThird.isSelected()))){
			lblCheckboxChoices.setText("Checkbox Choice(s): Second");
		}
		if((!(chckbxFirst.isSelected())) && (!(chckbxSecond.isSelected())) && chckbxThird.isSelected()){
			lblCheckboxChoices.setText("Checkbox Choice(s): Third");
		}
		if((!(chckbxFirst.isSelected())) && (!(chckbxSecond.isSelected())) && (!(chckbxThird.isSelected()))){
			lblCheckboxChoices.setText("Checkbox Choice(s):");
		}
	}
	protected void do_rdbtnOne_actionPerformed(ActionEvent e) {
		lblRadioChoice.setText("Radio Choice: One");
	}
	protected void do_rdbtnTwo_actionPerformed(ActionEvent e) {
		lblRadioChoice.setText("Radio Choice: Two");
	}
	protected void do_rdbtnThree_actionPerformed(ActionEvent e) {
		lblRadioChoice.setText("Radio Choice: Three");
	}
	protected void do_rdbtnFour_actionPerformed(ActionEvent e) {
		lblRadioChoice.setText("Radio Choice: Four");
	}
}
