import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.JLabel;

import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

import javax.swing.SwingConstants;


public class Sum extends JFrame {

	private JPanel contentPane;
	private final JTextField textField = new JTextField();
	private final JTextField textField_1 = new JTextField();
	private final JTextField textField_2 = new JTextField();
	private final JSeparator separator = new JSeparator();
	private final JTextField textField_3 = new JTextField();
	private final JLabel label = new JLabel("+");
	private final JTextField textField_4 = new JTextField();
	private final JTextField textField_5 = new JTextField();
	private final JLabel star1 = new JLabel("*");
	private final JLabel star2 = new JLabel("*");
	private final JLabel star3 = new JLabel("*");
	private final JLabel star4 = new JLabel("*");
	private final JLabel star5 = new JLabel("*");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Sum frame = new Sum();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Sum() {
		textField_5.setEditable(false);
		textField_5.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_5.setText("0");
		textField_5.setBounds(167, 197, 86, 20);
		textField_5.setColumns(10);
		textField_4.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_textField_4_focusLost(e);
			}
		});
		textField_4.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_4.setText("0");
		textField_4.setBounds(167, 155, 86, 20);
		textField_4.setColumns(10);
		textField_3.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent arg0) {
				do_textField_3_focusLost(arg0);
			}
		});
		textField_3.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_3.setText("0");
		textField_3.setDisabledTextColor(new Color(0,0,0));
		textField_3.setBounds(167, 124, 86, 20);
		textField_3.setColumns(10);
		textField_2.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_2.setText("0");
		textField_2.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_textField_2_focusLost(e);
			}
		});
		textField_2.setBounds(167, 93, 86, 20);
		textField_2.setColumns(10);
		textField_1.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_1.setText("0");
		textField_1.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_textField_1_focusLost(e);
			}
		});
		textField_1.setBounds(167, 62, 86, 20);
		textField_1.setColumns(10);
		textField.setHorizontalAlignment(SwingConstants.RIGHT);
		textField.setText("0");
		textField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_textField_focusLost(e);
			}
		});
		textField.setBounds(167, 30, 86, 20);
		textField.setColumns(10);
		jbInit();
	}
	private void jbInit() {
		setTitle("Aaron Kippins ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		contentPane.add(textField);
		
		contentPane.add(textField_1);
		
		contentPane.add(textField_2);
		separator.setBounds(167, 186, 86, 8);
		
		contentPane.add(separator);
		
		contentPane.add(textField_3);
		label.setBounds(142, 158, 15, 14);
		
		contentPane.add(label);
		
		contentPane.add(textField_4);
		
		contentPane.add(textField_5);
		star1.setVisible(false);
		star1.setForeground(Color.RED);
		star1.setBounds(263, 33, 15, 14);
		
		contentPane.add(star1);
		star2.setVisible(false);
		star2.setForeground(Color.RED);
		star2.setBounds(263, 65, 15, 14);
		
		contentPane.add(star2);
		star3.setVisible(false);
		star3.setForeground(Color.RED);
		star3.setBounds(263, 96, 15, 14);
		
		contentPane.add(star3);
		star4.setVisible(false);
		star4.setForeground(Color.RED);
		star4.setBounds(263, 127, 15, 14);
		
		contentPane.add(star4);
		star5.setVisible(false);
		star5.setForeground(Color.RED);
		star5.setBounds(263, 158, 15, 14);
		
		contentPane.add(star5);
	}
	protected void do_textField_focusLost(FocusEvent e) {
		sum();
	}
	protected void do_textField_1_focusLost(FocusEvent e) {
		sum();
	}
	protected void do_textField_2_focusLost(FocusEvent e) {
		sum();
	}
	protected void do_textField_3_focusLost(FocusEvent arg0) {
		sum();
	}
	protected void do_textField_4_focusLost(FocusEvent e) {
		sum();
	}
	private int sum(){
		int v = Integer.parseInt(textField.getText()); 
		int w = Integer.parseInt(textField_1.getText());
		int x = Integer.parseInt(textField_2.getText());
		int y = Integer.parseInt(textField_3.getText());
		int z = Integer.parseInt(textField_4.getText());
		int sum = v + w + x + y + z;
		if (v < 0){
			star1.setVisible(true);
		} else {
			star1.setVisible(false);
		}
		if (w < 0){
			star2.setVisible(true);
		} else {
			star2.setVisible(false);
		}
		if (x < 0){
			star3.setVisible(true);
		} else {
			star3.setVisible(false);
		}
		if (y < 0){
			star4.setVisible(true);
		} else {
			star4.setVisible(false);
		}
		if (z < 0){
			star5.setVisible(true);
		} else {
			star5.setVisible(false);
		}
		textField_5.setText(Integer.toString(sum));
		return sum;
	}
}
