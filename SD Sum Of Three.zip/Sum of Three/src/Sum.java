import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.JLabel;

import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

import javax.swing.SwingConstants;


public class Sum extends JFrame {

	private JPanel contentPane;
	private final JTextField textField = new JTextField();
	private final JTextField textField_1 = new JTextField();
	private final JTextField textField_2 = new JTextField();
	private final JSeparator separator = new JSeparator();
	private final JTextField textField_3 = new JTextField();
	private final JLabel label = new JLabel("+");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Sum frame = new Sum();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Sum() {
		textField_3.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_3.setText("0");
		textField_3.setEnabled(false);
		textField_3.setDisabledTextColor(new Color(0,0,0));
		textField_3.setBounds(159, 160, 86, 20);
		textField_3.setColumns(10);
		textField_2.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_2.setText("0");
		textField_2.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_textField_2_focusLost(e);
			}
		});
		textField_2.setBounds(159, 117, 86, 20);
		textField_2.setColumns(10);
		textField_1.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_1.setText("0");
		textField_1.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_textField_1_focusLost(e);
			}
		});
		textField_1.setBounds(159, 86, 86, 20);
		textField_1.setColumns(10);
		textField.setHorizontalAlignment(SwingConstants.RIGHT);
		textField.setText("0");
		textField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_textField_focusLost(e);
			}
		});
		textField.setBounds(159, 54, 86, 20);
		textField.setColumns(10);
		jbInit();
	}
	private void jbInit() {
		setTitle("Aaron Kippins ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		contentPane.add(textField);
		
		contentPane.add(textField_1);
		
		contentPane.add(textField_2);
		separator.setBounds(159, 148, 86, 8);
		
		contentPane.add(separator);
		
		contentPane.add(textField_3);
		label.setBounds(142, 120, 15, 14);
		
		contentPane.add(label);
	}
	protected void do_textField_focusLost(FocusEvent e) {
		sum();
	}
	protected void do_textField_1_focusLost(FocusEvent e) {
		sum();
	}
	protected void do_textField_2_focusLost(FocusEvent e) {
		sum();
	}
	private int sum(){
		int x = Integer.parseInt(textField.getText());
		int y = Integer.parseInt(textField_1.getText());
		int z = Integer.parseInt(textField_2.getText());
		int sum = x + y + z;
		textField_3.setText(Integer.toString(sum));
		return sum;
	}
}
