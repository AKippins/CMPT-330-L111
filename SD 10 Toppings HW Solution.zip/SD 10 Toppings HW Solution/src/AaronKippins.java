import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;


public class AaronKippins extends JFrame {

	private JPanel contentPane;
	private final JLabel lblKippinsPizzaria = new JLabel("Kippins' Pizzaria");
	private final JTextField nameTextField = new JTextField();
	private final JLabel lblName = new JLabel("Name:");
	private final JLabel lblSize = new JLabel("Size:");
	private final JComboBox comboBox = new JComboBox();
	private final JTextArea orderTextArea = new JTextArea();
	private final JButton btnPlaceOrder = new JButton("Place Order");
	private final JLabel lblToppings = new JLabel("Toppings:");
	private final JCheckBox chckbxPepperoni = new JCheckBox("Pepperoni");
	private final JCheckBox chckbxBacon = new JCheckBox("Bacon");
	private final JCheckBox chckbxSausage = new JCheckBox("Sausage");
	private final JCheckBox chckbxChicken = new JCheckBox("Chicken");
	private final JCheckBox chckbxSpinach = new JCheckBox("Spinach");
	private final JCheckBox chckbxMushrooms = new JCheckBox("Mushrooms");
	private final JCheckBox chckbxPeppers = new JCheckBox("Peppers");
	private final JCheckBox chckbxMeatballs = new JCheckBox("Meatballs");
	private final JCheckBox chckbxOnions = new JCheckBox("Onions");
	private final JCheckBox chckbxCanadianBacon = new JCheckBox("Canadian Bacon");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AaronKippins frame = new AaronKippins();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AaronKippins() {
		nameTextField.setBounds(69, 71, 112, 20);
		nameTextField.setColumns(10);
		jbInit();
	}
	private void jbInit() {
		setTitle("Aaron Kippins");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 358);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblKippinsPizzaria.setForeground(Color.BLUE);
		lblKippinsPizzaria.setFont(new Font("Magneto", Font.PLAIN, 25));
		lblKippinsPizzaria.setBounds(103, 21, 242, 29);
		
		contentPane.add(lblKippinsPizzaria);
		
		contentPane.add(nameTextField);
		lblName.setBounds(10, 74, 46, 14);
		
		contentPane.add(lblName);
		lblSize.setBounds(10, 99, 46, 14);
		
		contentPane.add(lblSize);
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Extra Large", "Large", "Medium", "Small", "Individual"}));
		comboBox.setBounds(69, 96, 112, 20);
		
		contentPane.add(comboBox);
		orderTextArea.setBounds(191, 61, 233, 126);
		
		contentPane.add(orderTextArea);
		btnPlaceOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnPlaceOrder_actionPerformed(e);
			}
		});
		btnPlaceOrder.setBounds(162, 290, 112, 23);
		
		contentPane.add(btnPlaceOrder);
		lblToppings.setBounds(10, 124, 56, 14);
		
		contentPane.add(lblToppings);
		chckbxPepperoni.setBounds(69, 120, 97, 23);
		
		contentPane.add(chckbxPepperoni);
		chckbxBacon.setBounds(69, 138, 97, 23);
		
		contentPane.add(chckbxBacon);
		chckbxSausage.setBounds(69, 156, 97, 23);
		
		contentPane.add(chckbxSausage);
		chckbxChicken.setBounds(69, 174, 97, 23);
		
		contentPane.add(chckbxChicken);
		chckbxSpinach.setBounds(69, 192, 97, 23);
		
		contentPane.add(chckbxSpinach);
		chckbxMushrooms.setBounds(69, 210, 97, 23);
		
		contentPane.add(chckbxMushrooms);
		chckbxPeppers.setBounds(69, 228, 97, 23);
		
		contentPane.add(chckbxPeppers);
		chckbxMeatballs.setBounds(168, 228, 97, 23);
		
		contentPane.add(chckbxMeatballs);
		chckbxOnions.setBounds(168, 210, 97, 23);
		
		contentPane.add(chckbxOnions);
		chckbxCanadianBacon.setBounds(168, 192, 112, 23);
		
		contentPane.add(chckbxCanadianBacon);
	}
	protected void do_btnPlaceOrder_actionPerformed(ActionEvent e) {
		orderTextArea.append("Hello, " + nameTextField.getText() + ".\nYou ordered a(n) \n" + comboBox.getSelectedItem().toString() + " pizza.\n" + "Your selected toppings are:\n" );
		
		if (chckbxPepperoni.getSelectedObjects() != null){
			orderTextArea.append(chckbxPepperoni.getText() + ", ");
		}
		if (chckbxBacon.getSelectedObjects() != null){
			orderTextArea.append(chckbxBacon.getText() + ", ");
		}
		if (chckbxSausage.getSelectedObjects() != null){
			orderTextArea.append(chckbxSausage.getText() + ",\n");
		}
		if (chckbxChicken.getSelectedObjects() != null){
			orderTextArea.append(chckbxChicken.getText() + ", ");
		}
		if (chckbxSpinach.getSelectedObjects() != null){
			orderTextArea.append(chckbxSpinach.getText() + ", ");
		}
		if (chckbxMushrooms.getSelectedObjects() != null){
			orderTextArea.append(chckbxMushrooms.getText() + ",\n");
		}
		if (chckbxPeppers.getSelectedObjects() != null){
			orderTextArea.append(chckbxPeppers.getText() + ", ");
		}
		if (chckbxMeatballs.getSelectedObjects() != null){
			orderTextArea.append(chckbxMeatballs.getText() + ", ");
		}
		if (chckbxOnions.getSelectedObjects() != null){
			orderTextArea.append(chckbxOnions.getText() + ",\n");
		}
		if (chckbxCanadianBacon.getSelectedObjects() != null){
			orderTextArea.append(chckbxCanadianBacon.getText() + "\n");
		}
		
	}
}
