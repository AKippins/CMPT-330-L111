import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.MaskFormatter;
import javax.swing.JLabel;
import javax.swing.JFormattedTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
//3 formatted text fields when the text field loses focus update letting the user know what field has the highest number

public class MaskEditHW extends JFrame {

	private JPanel contentPane;
	private final JLabel lblNum1 = new JLabel("Number 1");
	private final JFormattedTextField num1FTF = new JFormattedTextField();
	
	//define the First Number mask
	MaskFormatter num1Mask = createFormatter("#####");
	//define the Second Number mask 
	MaskFormatter num2Mask = createFormatter("#####");
	//define the Third Number Mask
	MaskFormatter num3Mask = createFormatter("#####");
	
	
	private final JLabel lblShowSsn = new JLabel("");
	private final JLabel lblNum2 = new JLabel("Number 2");
	private final JLabel lblNum3 = new JLabel("Number 3");
	private final JFormattedTextField num2FTF = new JFormattedTextField();
	private final JFormattedTextField num3FTF = new JFormattedTextField();
	private final JLabel lblShowSsn2 = new JLabel("");
	private final JLabel lblShowPhoneNumber = new JLabel("");
	private final JLabel lblShowState = new JLabel("");
	private final JLabel lblLargestNum = new JLabel("Hmmm The Largest Number Here Is.......");
	private final JLabel lblNumReveal = new JLabel("");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MaskEditHW frame = new MaskEditHW();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	//place this code after main()
	public MaskFormatter createFormatter(String s) {
	     MaskFormatter formatter = null;
	     try {
	          formatter = new MaskFormatter(s);
	         } 
	     catch (java.text.ParseException exc) {
		          System.err.println("formatter is bad: " + exc.getMessage());
		          System.exit(-1);
		      }
	      return formatter;
	}//createFormatter

	/**
	 * Create the frame.
	 */
	public MaskEditHW() {
		jbInit();
	}
	private void jbInit() {
		setTitle("Formatted Text And Mask Edits");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblNum1.setBounds(34, 21, 76, 17);
		
		contentPane.add(lblNum1);
		num1FTF.setText("0");
		num1FTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_num1FTF_focusLost(e);
			}
		});
		num1FTF.setBounds(34, 49, 76, 17);
		num1Mask.setPlaceholderCharacter('0');
		num1Mask.install(num1FTF);
		
		contentPane.add(num1FTF);
		lblShowSsn.setBounds(236, 35, 82, 14);
		
		contentPane.add(lblShowSsn);
		lblNum2.setBounds(180, 21, 76, 17);
		
		contentPane.add(lblNum2);
		lblNum3.setBounds(326, 21, 76, 17);
		
		contentPane.add(lblNum3);
		num2FTF.setText("0");
		num2FTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_num2FTF_focusLost(e);
			}
		});
		num2FTF.setBounds(180, 49, 76, 17);
		num2Mask.setPlaceholderCharacter('0');
		num2Mask.install(num2FTF);

		contentPane.add(num2FTF);
		num3FTF.setText("0");
		num3FTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_num3FTF_focusLost(e);
			}
		});
		num3FTF.setBounds(326, 49, 76, 17);
		num3Mask.setPlaceholderCharacter('0');
		num3Mask.install(num3FTF);
		
		contentPane.add(num3FTF);
		lblShowSsn2.setBounds(236, 60, 46, 14);
		
		contentPane.add(lblShowSsn2);
		lblShowPhoneNumber.setBounds(236, 91, 46, 14);
		
		contentPane.add(lblShowPhoneNumber);
		lblShowState.setBounds(236, 116, 46, 14);
		
		contentPane.add(lblShowState);
		lblLargestNum.setHorizontalAlignment(SwingConstants.CENTER);
		lblLargestNum.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblLargestNum.setBounds(10, 126, 414, 50);
		
		contentPane.add(lblLargestNum);
		lblNumReveal.setHorizontalAlignment(SwingConstants.CENTER);
		lblNumReveal.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNumReveal.setBounds(10, 190, 414, 50);
		
		contentPane.add(lblNumReveal);
	}
	private void largestNum(){
		int x = Integer.parseInt(num1FTF.getText());
		if (x < Integer.parseInt(num2FTF.getText())){
			x = Integer.parseInt(num2FTF.getText());
		}
		if (x < Integer.parseInt(num3FTF.getText())){
			x = Integer.parseInt(num3FTF.getText());
		}
		lblNumReveal.setText(Integer.toString(x));
	}
	protected void do_num1FTF_focusLost(FocusEvent e) {
		largestNum();
	}
	protected void do_num2FTF_focusLost(FocusEvent e) {
		largestNum();
	}
	protected void do_num3FTF_focusLost(FocusEvent e) {
		largestNum();
	}
}
