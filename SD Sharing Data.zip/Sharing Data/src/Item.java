
public class Item {
	private String myFirstVal;
	private String mySecondVal;
	private String myThirdVal;
	
	public Item(){
		myFirstVal = "";
		mySecondVal = "";
		myThirdVal = "";	
	}

	public Item(String a, String b, String c) {
		setMyFirstVal(a);
		setMySecondVal(b);
		setMyThirdVal(c);
	}
	
	public String getMyFirstVal() {
		return myFirstVal;
	}
	public void setMyFirstVal(String myFirstVal) {
		this.myFirstVal = myFirstVal;
	}
	public String getMySecondVal() {
		return mySecondVal;
	}
	public void setMySecondVal(String mySecondVal) {
		this.mySecondVal = mySecondVal;
	}
	public String getMyThirdVal() {
		return myThirdVal;
	}
	public void setMyThirdVal(String myThirdVal) {
		this.myThirdVal = myThirdVal;
	}
}
