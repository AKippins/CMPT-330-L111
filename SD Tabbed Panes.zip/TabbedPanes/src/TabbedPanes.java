import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTabbedPane;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class TabbedPanes extends JFrame {

	private JPanel contentPane;
	private final JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
	private final JPanel firstPanel = new JPanel();
	private final JLabel lblHey = new JLabel("Hey");
	private final JButton btnClickMe = new JButton("Click Me");
	private final JPanel secondPanel = new JPanel();
	private final JLabel lblSecond = new JLabel("Second");
	private final JPasswordField passwordField = new JPasswordField();
	private final JLabel lblPassword = new JLabel("The Password Is :");
	private final JButton btnEnter = new JButton("Enter");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TabbedPanes frame = new TabbedPanes();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TabbedPanes() {
		jbInit();
	}
	private void jbInit() {
		setTitle("Aaron Kippins");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		tabbedPane.setBounds(10, 11, 414, 239);
		
		contentPane.add(tabbedPane);
		
		tabbedPane.addTab("First", null, firstPanel, null);
		firstPanel.setLayout(null);
		lblHey.setBounds(146, 60, 46, 14);
		
		firstPanel.add(lblHey);
		btnClickMe.setBounds(146, 98, 89, 23);
		
		firstPanel.add(btnClickMe);
		passwordField.setBounds(146, 132, 89, 23);
		
		firstPanel.add(passwordField);
		lblPassword.setBounds(146, 166, 253, 14);
		
		firstPanel.add(lblPassword);
		btnEnter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_btnEnter_actionPerformed(arg0);
			}
		});
		btnEnter.setBounds(245, 132, 89, 23);
		
		firstPanel.add(btnEnter);
		
		tabbedPane.addTab("Second", null, secondPanel, null);
		secondPanel.setLayout(null);
		lblSecond.setBounds(148, 24, 46, 14);
		
		secondPanel.add(lblSecond);
	}
	protected void do_btnEnter_actionPerformed(ActionEvent arg0) {
		lblPassword.setText("The Password Is : " + passwordField.getText());
	}
}
