import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class theFrame extends JFrame {

	private JPanel contentPane;
	private final JLabel lblHello = new JLabel("Hello");
	private final JLabel lblGoodbye = new JLabel("Goodbye");
	private final JButton btnClickMe = new JButton("Click Me");
	private final JButton btnNewIt = new JButton("New It");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					theFrame frame = new theFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public theFrame() {
		jbInit();
	}
	private void jbInit() {
		setTitle("Aaron Kippins");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblHello.setForeground(new Color(0, 128, 128));
		lblHello.setFont(new Font("Old English Text MT", Font.PLAIN, 22));
		lblHello.setBounds(156, 58, 140, 23);
		
		contentPane.add(lblHello);
		lblGoodbye.setForeground(new Color(255, 0, 255));
		lblGoodbye.setFont(new Font("Broadway", Font.PLAIN, 30));
		lblGoodbye.setBounds(145, 92, 151, 56);
		
		contentPane.add(lblGoodbye);
		btnClickMe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnClickMe_actionPerformed(e);
			}
		});
		btnClickMe.setBounds(175, 183, 89, 23);
		
		contentPane.add(btnClickMe);
		btnNewIt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnNewIt_actionPerformed(e);
			}
		});
		btnNewIt.setBounds(175, 217, 89, 23);
		
		contentPane.add(btnNewIt);
	}
	protected void do_btnClickMe_actionPerformed(ActionEvent e) {
		String Hello = lblHello.getText();
		lblHello.setText(lblGoodbye.getText());
		lblGoodbye.setText(Hello);
	}
	protected void do_btnNewIt_actionPerformed(ActionEvent e) {
		lblHello.setText("new" + lblHello.getText());
	}
}
