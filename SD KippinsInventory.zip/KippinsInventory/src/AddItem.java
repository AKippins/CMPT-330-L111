import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;

import java.awt.Font;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;


public class AddItem extends JFrame {

	private JPanel contentPane;
	private final JLabel lblItemName = new JLabel("Item Name");
	private final JLabel lblCategory = new JLabel("Category");
	private final JLabel lblWholesalePrice = new JLabel("Wholesale Price");
	private final JLabel lblRetailPrice = new JLabel("Retail Price");
	private final JLabel lblQoh = new JLabel("QOH");
	private final JLabel lblMinimumQuantity = new JLabel("Minimum Quantity");
	private final JLabel lblClerk = new JLabel("Clerk");
	private final JTextField ItemNameTF = new JTextField();
	private final JTextField WholesalePTF = new JTextField();
	private final JTextField RetailPTF = new JTextField();
	private final JTextField QOHTF = new JTextField();
	private final JTextField MinimumQTF = new JTextField();
	private final JTextField ClerkTF = new JTextField();
	private final JLabel lblAddAnItem = new JLabel("Add An Item");
	private final JButton btnAddItem = new JButton("Add Item");
	private final JComboBox CategoryCB = new JComboBox();
	private final JButton btnCancel = new JButton("Cancel");
	private final JTextField IDTF = new JTextField();
	private final JLabel lblId = new JLabel("ID");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddItem frame = new AddItem();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddItem() {
		IDTF.setToolTipText("Enter an ID");
		IDTF.setBounds(37, 78, 86, 20);
		IDTF.setColumns(10);
		ClerkTF.setToolTipText("Enter the clerk who last enter information abpout the selected item into the database");
		ClerkTF.setText("");
		ClerkTF.setBounds(788, 78, 86, 20);
		ClerkTF.setColumns(10);
		MinimumQTF.setToolTipText("Enter the Minimum Quantity allowed at a time");
		MinimumQTF.setBounds(681, 78, 86, 20);
		MinimumQTF.setColumns(10);
		QOHTF.setToolTipText("Enter the Quantity On Hand");
		QOHTF.setText("");
		QOHTF.setBounds(574, 78, 86, 20);
		QOHTF.setColumns(10);
		RetailPTF.setToolTipText("Enter an Retail Price");
		RetailPTF.setText("");
		RetailPTF.setBounds(467, 78, 86, 20);
		RetailPTF.setColumns(10);
		WholesalePTF.setToolTipText("Enter an Wholesale Price");
		WholesalePTF.setBounds(360, 78, 86, 20);
		WholesalePTF.setColumns(10);
		ItemNameTF.setToolTipText("Enter an Item Name");
		ItemNameTF.setBounds(146, 78, 86, 20);
		ItemNameTF.setColumns(10);
		jbInit();
	}
	private void jbInit() {
		setTitle("Add Item");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 916, 192);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblItemName.setBounds(146, 53, 102, 14);
		
		contentPane.add(lblItemName);
		lblCategory.setBounds(253, 53, 102, 14);
		
		contentPane.add(lblCategory);
		lblWholesalePrice.setBounds(360, 53, 102, 14);
		
		contentPane.add(lblWholesalePrice);
		lblRetailPrice.setBounds(467, 53, 102, 14);
		
		contentPane.add(lblRetailPrice);
		lblQoh.setBounds(574, 53, 102, 14);
		
		contentPane.add(lblQoh);
		lblMinimumQuantity.setBounds(681, 53, 102, 14);
		
		contentPane.add(lblMinimumQuantity);
		lblClerk.setBounds(788, 53, 102, 14);
		
		contentPane.add(lblClerk);
		
		contentPane.add(ItemNameTF);
		
		contentPane.add(WholesalePTF);
		
		contentPane.add(RetailPTF);
		
		contentPane.add(QOHTF);
		
		contentPane.add(MinimumQTF);
		
		contentPane.add(ClerkTF);
		lblAddAnItem.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblAddAnItem.setBounds(362, 11, 175, 31);
		
		contentPane.add(lblAddAnItem);
		btnAddItem.setToolTipText("Add Item to the Database");
		btnAddItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnAddItem_actionPerformed(e);
			}
		});
		btnAddItem.setBounds(350, 119, 89, 23);
		
		contentPane.add(btnAddItem);
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		} catch (ClassNotFoundException e){
			e.printStackTrace();
		}
		CategoryCB.setToolTipText("Select a Category");
		CategoryCB.setModel(new DefaultComboBoxModel(new String[] {"Dairy", "Meat ", "Frozen ", "Canned ", "Produce ", "Beverage ", "Paper", "Snack ", "Cereal", "Other"}));
		CategoryCB.setBounds(253, 78, 86, 20);
		
		contentPane.add(CategoryCB);
		btnCancel.setToolTipText("Abort the entry");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnCancel_actionPerformed(e);
			}
		});
		btnCancel.setBounds(448, 119, 89, 23);
		
		contentPane.add(btnCancel);
		
		contentPane.add(IDTF);
		lblId.setBounds(37, 53, 46, 14);
		
		contentPane.add(lblId);
	}
	protected void do_btnAddItem_actionPerformed(ActionEvent e) {
		//I figured it would be better to have the connection to add to the database here since the add function is only used here.
		Statement stmt = null;
		ResultSet rs = null;
		try {
			//Establishing the connection
			Connection conn = DriverManager.getConnection("jdbc:odbc:KippinsDatabase");
			
			//Checking the database to see if there is an item with the id selected assigned already
			stmt = conn.createStatement();
			String theQuery = "Select ItemID From Inventory Where ItemID = " + IDTF.getText().trim() ;
			rs = stmt.executeQuery(theQuery);
			
			if (rs.next())
				System.out.println("Nope");
			else {
				//Starting the connection
				/*stmt = conn.createStatement();
				String query = "Select ItemID From Inventory Order By ItemID Desc";
				System.out.println(query);*/
				
				//Executing the Statement
				//rs = stmt.executeQuery(query);
				
				stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
				
				/*rs.next();
				int ID = rs.getInt("ItemID") + 1;
				System.out.println(ID);*/
				
				if(IDTF.getText().isEmpty() || ItemNameTF.getText().isEmpty() || WholesalePTF.getText().isEmpty() || RetailPTF.getText().isEmpty() || QOHTF.getText().isEmpty() || MinimumQTF.getText().isEmpty() || ClerkTF.getText().isEmpty()){
					JOptionPane.showMessageDialog(null , "Please make sure that you have an input in all fields", "Error", JOptionPane.ERROR_MESSAGE);
				} else {
				
				String InsertQuery = "Insert Into Inventory Values('";
						InsertQuery += IDTF.getText().trim() + "', "; 
						InsertQuery += "'" + ItemNameTF.getText().trim() + "', ";
						InsertQuery += "'" + CategoryCB.getSelectedItem() + "', ";
						InsertQuery += "'" + WholesalePTF.getText().trim() + "', ";
						InsertQuery += "'" + RetailPTF.getText().trim() + "', ";
						InsertQuery += "'" + QOHTF.getText().trim() + "', ";
						InsertQuery += "'" + MinimumQTF.getText().trim() + "', ";
						InsertQuery += "'" + ClerkTF.getText().trim() + "')";
						
				System.out.println(InsertQuery);
				if (stmt.executeUpdate(InsertQuery) != 0){
					System.out.println("Success");
					JOptionPane.showMessageDialog(null, "You have successfully added an item to the inventory.");
					this.dispose();
				} else {
					System.out.println("Nope");
				}
				
				rs.close();
				conn.close();
				}
			}		
		} catch (SQLException ex) {
			System.out.println("SQL Exception: " + ex.getMessage());
			System.out.println("SQL State: " + ex.getSQLState());
			System.out.println("Vendor Error: " + ex.getErrorCode());
			ex.printStackTrace();
		}
		
	}
	protected void do_btnCancel_actionPerformed(ActionEvent e) {
		//Cancel will just exit this window instead of all of the frames.
		this.dispose();
	}
}
