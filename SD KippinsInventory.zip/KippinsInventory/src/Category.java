import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Category extends JFrame {

	private JPanel contentPane;
	private final JLabel lblFilterByCategory = new JLabel("Filter By Category");
	private final JButton btnFilter = new JButton("Filter");
	private final JButton btnCancel = new JButton("Cancel");
	private final JCheckBox CBDairy = new JCheckBox("Dairy");
	private final JCheckBox CBMeat = new JCheckBox("Meat");
	private final JCheckBox CBFrozen = new JCheckBox("Frozen");
	private final JCheckBox CBCanned = new JCheckBox("Canned");
	private final JCheckBox CBProduce = new JCheckBox("Produce");
	private final JCheckBox CBBeverage = new JCheckBox("Beverage");
	private final JCheckBox CBPaper = new JCheckBox("Paper");
	private final JCheckBox CBSnack = new JCheckBox("Snack");
	private final JCheckBox CBCereal = new JCheckBox("Cereal");
	private final JCheckBox CBOther = new JCheckBox("Other");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Category frame = new Category();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Category() {
		jbInit();
	}
	private void jbInit() {
		setTitle("Filter By Category");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 436, 283);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblFilterByCategory.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblFilterByCategory.setBounds(88, 11, 243, 38);
		
		contentPane.add(lblFilterByCategory);
		btnFilter.setToolTipText("Filter by the selected options");
		btnFilter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnFilter_actionPerformed(e);
			}
		});
		btnFilter.setBounds(98, 201, 89, 23);
		
		contentPane.add(btnFilter);
		btnCancel.setToolTipText("Abort the filter");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnCancel_actionPerformed(e);
			}
		});
		btnCancel.setBounds(205, 201, 89, 23);
		
		contentPane.add(btnCancel);
		CBDairy.setToolTipText("Select Dairy");
		CBDairy.setBounds(98, 56, 97, 23);
		
		contentPane.add(CBDairy);
		CBMeat.setToolTipText("Select Meat");
		CBMeat.setBounds(98, 82, 97, 23);
		
		contentPane.add(CBMeat);
		CBFrozen.setToolTipText("Select  Frozen");
		CBFrozen.setBounds(98, 108, 97, 23);
		
		contentPane.add(CBFrozen);
		CBCanned.setToolTipText("Select Canned");
		CBCanned.setBounds(98, 134, 97, 23);
		
		contentPane.add(CBCanned);
		CBProduce.setToolTipText("Select Produce");
		CBProduce.setBounds(98, 160, 97, 23);
		
		contentPane.add(CBProduce);
		CBBeverage.setToolTipText("Select Beverage");
		CBBeverage.setBounds(197, 56, 97, 23);
		
		contentPane.add(CBBeverage);
		CBPaper.setToolTipText("Paper");
		CBPaper.setBounds(197, 82, 97, 23);
		
		contentPane.add(CBPaper);
		CBSnack.setToolTipText("Select Snack");
		CBSnack.setBounds(197, 108, 97, 23);
		
		contentPane.add(CBSnack);
		CBCereal.setToolTipText("Select Cereal");
		CBCereal.setBounds(197, 134, 97, 23);
		
		contentPane.add(CBCereal);
		CBOther.setToolTipText("Select Other");
		CBOther.setBounds(197, 160, 97, 23);
		
		contentPane.add(CBOther);
	}
	protected void do_btnFilter_actionPerformed(ActionEvent e) {
		String query = "Select * From Inventory Where ";
		boolean oneSelected = false;
		
		if (CBDairy.isSelected()){
			if (!oneSelected){
				query += "Category = 'Dairy'";
				oneSelected = true;
			} else {
				query += " Or Category = 'Dairy'";
			}
		}
		if (CBMeat.isSelected()){
			if (!oneSelected){
				query += "Category = 'Meat'";
				oneSelected = true;
			} else {
				query += " Or Category = 'Meat'";
			}
		}
		if (CBFrozen.isSelected()){
			if (!oneSelected){
				query += "Category = 'Frozen'";
				oneSelected = true;
			} else {
				query += " Or Category = 'Frozen'";
			}
		}
		if (CBCanned.isSelected()){
			if (!oneSelected){
				query += "Category = 'Canned'";
				oneSelected = true;
			} else {
				query += " Or Category = 'Canned'";
			}
		}
		if (CBProduce.isSelected()){
			if (!oneSelected){
				query += "Category = 'Produce'";
				oneSelected = true;
			} else {
				query += " Or Category = 'Produce'";
			}
		}
		if (CBBeverage.isSelected()){
			if (!oneSelected){
				query += "Category = 'Beverage'";
				oneSelected = true;
			} else {
				query += " Or Category = 'Beverage'";
			}
		}
		if (CBPaper.isSelected()){
			if (!oneSelected){
				query += "Category = 'Paper'";
				oneSelected = true;
			} else {
				query += " Or Category = 'Paper'";
			}
		}
		if (CBSnack.isSelected()){
			if (!oneSelected){
				query += "Category = 'Snack'";
				oneSelected = true;
			} else {
				query += " Or Category = 'Snack'";
			}
		}
		if (CBCereal.isSelected()){
			if (!oneSelected){
				query += "Category = 'Cereal'";
				oneSelected = true;
			} else {
				query += " Or Category = 'Cereal'";
			}
		}
		if (CBOther.isSelected()){
			if (!oneSelected){
				query += "Category = 'Other'";
				oneSelected = true;
			} else {
				query += " Or Category = 'Other'";
			}
		}
		
		System.out.println(query);
		this.setVisible(false);
		Inventory Main = new Inventory();
		
		Main.Query(query);
		Main.setVisible(true);
		
		//Setting the active state label
		query = "";
		oneSelected = false;
		
		if (CBDairy.isSelected()){
			if (!oneSelected){
				query += "Category = 'Dairy'";
				oneSelected = true;
			} else {
				query += " Or Category = 'Dairy'";
			}
		}
		if (CBMeat.isSelected()){
			if (!oneSelected){
				query += "Category = 'Meat'";
				oneSelected = true;
			} else {
				query += " Or Category = 'Meat'";
			}
		}
		if (CBFrozen.isSelected()){
			if (!oneSelected){
				query += "Category = 'Frozen'";
				oneSelected = true;
			} else {
				query += " Or Category = 'Frozen'";
			}
		}
		if (CBCanned.isSelected()){
			if (!oneSelected){
				query += "Category = 'Canned'";
				oneSelected = true;
			} else {
				query += " Or Category = 'Canned'";
			}
		}
		if (CBProduce.isSelected()){
			if (!oneSelected){
				query += "Category = 'Produce'";
				oneSelected = true;
			} else {
				query += " Or Category = 'Produce'";
			}
		}
		if (CBBeverage.isSelected()){
			if (!oneSelected){
				query += "Category = 'Beverage'";
				oneSelected = true;
			} else {
				query += " Or Category = 'Beverage'";
			}
		}
		if (CBPaper.isSelected()){
			if (!oneSelected){
				query += "Category = 'Paper'";
				oneSelected = true;
			} else {
				query += " Or Category = 'Paper'";
			}
		}
		if (CBSnack.isSelected()){
			if (!oneSelected){
				query += "Category = 'Snack'";
				oneSelected = true;
			} else {
				query += " Or Category = 'Snack'";
			}
		}
		if (CBCereal.isSelected()){
			if (!oneSelected){
				query += "Category = 'Cereal'";
				oneSelected = true;
			} else {
				query += " Or Category = 'Cereal'";
			}
		}
		if (CBOther.isSelected()){
			if (!oneSelected){
				query += "Category = 'Other'";
				oneSelected = true;
			} else {
				query += " Or Category = 'Other'";
			}
		}
		Main.ActiveState.setText(query);
	}
	protected void do_btnCancel_actionPerformed(ActionEvent e) {
		this.dispose();
	}
}
