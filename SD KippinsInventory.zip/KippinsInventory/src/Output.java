
public class Output {
	private String Output;
	
	public Output() {
		Output = "";
	}
	
	public Output(String output) {
		setOutput(output);
	}

	public String getOutput() {
		return Output;
	}

	public void setOutput(String output) {
		Output = output;
	}
}
