import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JSeparator;


public class Help extends JFrame {

	private JPanel contentPane;
	private final JLabel lblInventory = new JLabel("Inventory");
	private final JLabel lblTheBasicFunctionality = new JLabel("The basic functionality of this page is to display the status of the inventory. This page ");
	private final JLabel lblAClearButton = new JLabel("also has a clear button that shows the inventory sorted by the ID Number.  From this ");
	private final JLabel lblPageYouAre = new JLabel("page you are able to access an exit option, an add item option, and sort and filter options.");
	private final JLabel lblAddItem = new JLabel("Add Item");
	private final JLabel lblThisWindowAllows = new JLabel("This window allows the user the ability to add items to the inventory. This lets the user ");
	private final JLabel lblEnterDataInto = new JLabel("enter data into the given fields. From here the add item button will input the the item or you ");
	private final JLabel lblCanSelectThe = new JLabel("can select the cancel button that will close the window and no changes will be made.");
	private final JLabel lblSorting = new JLabel("Sorting ");
	private final JLabel lblSelectingOnOf = new JLabel("Selecting on of the options will allow the user to see the query sorted by the selected field.");
	private final JLabel lblFiltering = new JLabel("Filtering");
	private final JLabel lblFilteringWillAllow = new JLabel("Filtering will allow the user to input a few choices and view the Inventory based on the ");
	private final JLabel lblValuesSelected = new JLabel("values selected.");
	private final JSeparator separator = new JSeparator();
	private final JSeparator separator_1 = new JSeparator();
	private final JSeparator separator_2 = new JSeparator();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Help frame = new Help();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Help() {
		jbInit();
	}
	private void jbInit() {
		setTitle("Need help???");
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 543, 483);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblInventory.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblInventory.setBounds(10, 11, 96, 19);
		
		contentPane.add(lblInventory);
		lblTheBasicFunctionality.setBounds(10, 42, 497, 14);
		
		contentPane.add(lblTheBasicFunctionality);
		lblAClearButton.setBounds(10, 67, 497, 14);
		
		contentPane.add(lblAClearButton);
		lblPageYouAre.setBounds(10, 92, 507, 14);
		
		contentPane.add(lblPageYouAre);
		lblAddItem.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblAddItem.setBounds(10, 129, 96, 19);
		
		contentPane.add(lblAddItem);
		lblThisWindowAllows.setBounds(10, 159, 507, 14);
		
		contentPane.add(lblThisWindowAllows);
		lblEnterDataInto.setBounds(10, 184, 529, 14);
		
		contentPane.add(lblEnterDataInto);
		lblCanSelectThe.setBounds(10, 209, 497, 14);
		
		contentPane.add(lblCanSelectThe);
		lblSorting.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblSorting.setBounds(10, 248, 59, 19);
		
		contentPane.add(lblSorting);
		lblSelectingOnOf.setBounds(10, 278, 529, 14);
		
		contentPane.add(lblSelectingOnOf);
		lblFiltering.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblFiltering.setBounds(10, 316, 64, 19);
		
		contentPane.add(lblFiltering);
		lblFilteringWillAllow.setBounds(10, 346, 507, 14);
		
		contentPane.add(lblFilteringWillAllow);
		lblValuesSelected.setBounds(10, 371, 111, 14);
		
		contentPane.add(lblValuesSelected);
		separator.setBounds(10, 117, 507, 2);
		
		contentPane.add(separator);
		separator_1.setBounds(10, 234, 507, 2);
		
		contentPane.add(separator_1);
		separator_2.setBounds(10, 303, 507, 2);
		
		contentPane.add(separator_2);
	}
}
