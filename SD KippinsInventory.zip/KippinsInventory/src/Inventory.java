import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JLabel;
import java.awt.Font;


public class Inventory extends JFrame {

	private JPanel contentPane;
	private final JMenuBar menuBar = new JMenuBar();
	private final JMenu mnFile = new JMenu("File");
	private final JMenu mnTools = new JMenu("Tools");
	private final JMenu mnHelp = new JMenu("Help");
	private final JMenuItem mntmExit = new JMenuItem("Exit");
	private final JMenuItem mntmAddItem = new JMenuItem("Add Item");
	private final JMenu mnSetSort = new JMenu("Set Sort");
	private final JMenu mnSetFilter = new JMenu("Set Filter ");
	private final JMenuItem mntmByName = new JMenuItem("By Name");
	private final JMenuItem mntmByRetailPrice = new JMenuItem("By Retail Price");
	private final JMenuItem mntmByCategory = new JMenuItem("By Category");
	private final JMenuItem mntmByRetailPrice_1 = new JMenuItem("By Retail Price");
	private final JMenuItem mntmByCategory_1 = new JMenuItem("By Category");
	private final JTextArea textArea = new JTextArea();
	private final JScrollPane scrollPane = new JScrollPane();
	private final JButton btnQuery = new JButton("Reset Database");
	private final JLabel lblInventory = new JLabel("Inventory");
	private Output queryOutput;
	private final JMenuItem mntmNeedHelp = new JMenuItem("Need Help???");
	final JLabel ActiveState = new JLabel("Ordered By ID");
	private final JButton btnClose = new JButton("Close");
	private final JLabel lblId = new JLabel("ID");
	private final JLabel lblItemName = new JLabel("Item Name");
	private final JLabel lblCategory = new JLabel("Category");
	private final JLabel lblRetail = new JLabel("Retail");
	private final JLabel lblWholesale = new JLabel("Wholesale");
	private final JLabel lblPrice = new JLabel("Price");
	private final JLabel lblPrice_1 = new JLabel("Price");
	private final JLabel lblQoh = new JLabel("QOH");
	private final JLabel lblMinimum = new JLabel("Minimum");
	private final JLabel lblQuantity = new JLabel("Quantity");
	private final JLabel lblClerk = new JLabel("Clerk");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Inventory frame = new Inventory();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Inventory() {
		jbInit();
		Query("Select * From Inventory");
	}
	private void jbInit() {
		setTitle("Inventory");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 710, 475);
		
		setJMenuBar(menuBar);
		
		menuBar.add(mnFile);
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_mntmExit_actionPerformed(arg0);
			}
		});
		
		mnFile.add(mntmExit);
		
		menuBar.add(mnTools);
		mntmAddItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmAddItem_actionPerformed(e);
			}
		});
		
		mnTools.add(mntmAddItem);
		
		mnTools.add(mnSetSort);
		mntmByName.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmByName_actionPerformed(e);
			}
		});
		
		mnSetSort.add(mntmByName);
		mntmByRetailPrice.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmByRetailPrice_actionPerformed(e);
			}
		});
		
		mnSetSort.add(mntmByRetailPrice);
		mntmByCategory.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmByCategory_actionPerformed(e);
			}
		});
		
		mnSetSort.add(mntmByCategory);
		
		mnTools.add(mnSetFilter);
		mntmByRetailPrice_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmByRetailPrice_1_actionPerformed(e);
			}
		});
		
		mnSetFilter.add(mntmByRetailPrice_1);
		mntmByCategory_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmByCategory_1_actionPerformed(e);
			}
		});
		
		mnSetFilter.add(mntmByCategory_1);
		
		menuBar.add(mnHelp);
		mntmNeedHelp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmNeedHelp_actionPerformed(e);
			}
		});
		
		mnHelp.add(mntmNeedHelp);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		scrollPane.setBounds(10, 84, 674, 292);
		
		contentPane.add(scrollPane);
		textArea.setToolTipText("Where the queries will be displayed");
		scrollPane.setViewportView(textArea);
		btnQuery.setToolTipText("Click to reinitialize the database");
		btnQuery.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_btnQuery_actionPerformed(arg0);
			}
		});
		btnQuery.setBounds(221, 381, 141, 23);
		
		contentPane.add(btnQuery);
		try{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		} catch (ClassNotFoundException e){
			e.printStackTrace();
		}
		lblInventory.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblInventory.setBounds(276, 11, 141, 29);
		
		contentPane.add(lblInventory);
		ActiveState.setBounds(10, 43, 674, 14);
		
		contentPane.add(ActiveState);
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnClose_actionPerformed(e);
			}
		});
		btnClose.setBounds(373, 381, 89, 23);
		
		contentPane.add(btnClose);
		lblId.setBounds(10, 68, 46, 14);
		
		contentPane.add(lblId);
		lblItemName.setBounds(90, 68, 83, 14);
		
		contentPane.add(lblItemName);
		lblCategory.setBounds(183, 68, 67, 14);
		
		contentPane.add(lblCategory);
		lblRetail.setBounds(260, 51, 46, 14);
		
		contentPane.add(lblRetail);
		lblWholesale.setBounds(322, 51, 80, 14);
		
		contentPane.add(lblWholesale);
		lblPrice.setBounds(334, 68, 46, 14);
		
		contentPane.add(lblPrice);
		lblPrice_1.setBounds(260, 68, 46, 14);
		
		contentPane.add(lblPrice_1);
		lblQoh.setBounds(408, 68, 46, 14);
		
		contentPane.add(lblQoh);
		lblMinimum.setBounds(467, 51, 83, 14);
		
		contentPane.add(lblMinimum);
		lblQuantity.setBounds(467, 68, 89, 14);
		
		contentPane.add(lblQuantity);
		lblClerk.setBounds(565, 68, 46, 14);
		
		contentPane.add(lblClerk);
	}
	protected void do_btnQuery_actionPerformed(ActionEvent arg0) {
		String query = "Select * From Inventory";
		System.out.println(query);
		ActiveState.setText("Ordered By ID");
		Query(query);
	}
	protected void do_mntmExit_actionPerformed(ActionEvent arg0) {
		this.dispose();
	}
	protected void do_mntmAddItem_actionPerformed(ActionEvent e) {
		//Linked to call AddItem.java
		AddItem AddTab = new AddItem();
		AddTab.setVisible(true);
	}
	protected void do_mntmByName_actionPerformed(ActionEvent e) {
		String query = "Select * From Inventory Order By ItemName ASC";
		System.out.println(query);
		ActiveState.setText("Ordered By Item Name");
		Query(query);
	}
	protected void do_mntmByRetailPrice_actionPerformed(ActionEvent e) {
		String query = "Select * From Inventory Order By RetailPrice ASC";
		System.out.println(query);
		ActiveState.setText("Ordered By Retail Price");
		Query(query);
	}
	protected void do_mntmByCategory_actionPerformed(ActionEvent e) {
		String query = "Select * From Inventory Order By Category ASC";
		System.out.println(query);
		ActiveState.setText("Ordered By Category");
		Query(query);
	}
	protected void do_mntmByRetailPrice_1_actionPerformed(ActionEvent e) {
		//Linked to call RetailPrice.java
		RetailPrice Retail = new RetailPrice();
		Retail.setVisible(true);
		this.dispose();
	}
	protected void do_mntmByCategory_1_actionPerformed(ActionEvent e) {
		//Linked to call Category.java
		Category Category = new Category();
		Category.setVisible(true);
		this.dispose();
	}
	void Query(String query){
		//Set query as it's own method so that i wouldn't have to go through the procedure to connect every time i just sent a query and it works normally
		Statement stmt = null;
		ResultSet rs = null;
		try{
			//Establish the connection
			Connection conn = DriverManager.getConnection("jdbc:odbc:KippinsDatabase");
			
			//Create the connection
			stmt = conn.createStatement();
			//String query = "Select * From Inventory";
			System.out.println(query);
			
			//Execute the query
			rs = stmt.executeQuery(query);
			
			//Clears the text area for a new query to be entered
			textArea.setText("");
			
			
			
			while (rs.next()){
				String ID = String.format("%-10s", rs.getInt("ItemID"));
				String ItemName= String.format("%20s", rs.getString("ItemName"));
				String Category= String.format("%25s", rs.getString("Category"));
				String wPrice = String.format("%15s", rs.getDouble("WholesalePrice"));
				String rPrice = String.format("%20s", rs.getDouble("RetailPrice"));
				String QOH = String.format("%20s", rs.getInt("QOH"));
				String MinQuant = String.format("%20s", rs.getInt("MinQuant"));
				String Clerk = String.format("%25s", rs.getString("Clerk"));
				
				textArea.append(ID + " " + ItemName + " " + Category + " " + wPrice + " " + rPrice + " " + QOH + " " + MinQuant + " " + Clerk + "\n");
			}
			rs.close();
			conn.close();
		} catch (SQLException ex) {
			System.out.println("SQL Exception: " + ex.getMessage());
			System.out.println("SQL State: " + ex.getSQLState());
			System.out.println("Vendor Error: " + ex.getErrorCode());
			ex.printStackTrace();
		}
	}
	protected void do_mntmNeedHelp_actionPerformed(ActionEvent e) {
		Help help = new Help();
		help.setVisible(true);
	}
	protected void do_btnClose_actionPerformed(ActionEvent e) {
		this.dispose();
	}
}
