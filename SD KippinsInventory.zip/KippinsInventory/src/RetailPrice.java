import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.MaskFormatter;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFormattedTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import org.eclipse.wb.swing.FocusTraversalOnArray;

import java.awt.Component;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.SwingConstants;


public class RetailPrice extends JFrame {

	private JPanel contentPane;
	private final JLabel lblShowItemsThat = new JLabel("Show items that are");
	private final JComboBox comboBox = new JComboBox();
	private final JFormattedTextField FTFSort = new JFormattedTextField();
	private final JLabel RangeSort = new JLabel("$");
	private final JButton btnFilter = new JButton("Filter");
	private final JButton btnCancel = new JButton("Cancel");
	private final JFormattedTextField FTFRange = new JFormattedTextField();
	private final JLabel DollarSort = new JLabel("$");
	private final JLabel lblFilterByRetail = new JLabel("Filter By Retail Price");
	MaskFormatter FTFSortM = createFormatter("##.##");
	MaskFormatter FTFRangeM = createFormatter("##.##");
	private Output queryOutput;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RetailPrice frame = new RetailPrice();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public MaskFormatter createFormatter(String s) {
	     MaskFormatter formatter = null;
	     try {
	          formatter = new MaskFormatter(s);
	         } 
	     catch (java.text.ParseException exc) {
		          System.err.println("formatter is bad: " + exc.getMessage());
		          System.exit(-1);
		      }
	      return formatter;
	}
	/**
	 * Create the frame.
	 */
	public RetailPrice() {
		jbInit();
	}
	private void jbInit() {
		FTFSortM.setPlaceholderCharacter('#');
		FTFRangeM.setPlaceholderCharacter('#');
		FTFSortM.install(FTFSort);
		FTFRangeM.install(FTFRange);

		setTitle("Filter By Retail Price");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 212);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblShowItemsThat.setBounds(97, 50, 119, 14);
		
		contentPane.add(lblShowItemsThat);
		comboBox.setToolTipText("Select your method of sort");
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_comboBox_actionPerformed(e);
			}
		});
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Less Than", "More Than", "In The Range Of"}));
		comboBox.setBounds(216, 47, 135, 20);
		
		contentPane.add(comboBox);
		FTFSort.setToolTipText("Enter a number to sort by");
		FTFSort.setHorizontalAlignment(SwingConstants.RIGHT);
		FTFSort.setBounds(180, 75, 55, 20);
		
		contentPane.add(FTFSort);
		RangeSort.setBounds(170, 109, 25, 14);
		RangeSort.setVisible(false);
		
		contentPane.add(RangeSort);
		btnFilter.setToolTipText("Submit the filter");
		btnFilter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnFilter_actionPerformed(e);
			}
		});
		btnFilter.setBounds(117, 137, 89, 23);
		
		contentPane.add(btnFilter);
		btnCancel.setToolTipText("Abort the filter");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnCancel_actionPerformed(e);
			}
		});
		btnCancel.setBounds(223, 137, 89, 23);
		
		contentPane.add(btnCancel);
		contentPane.setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{lblShowItemsThat, comboBox, RangeSort, FTFSort, btnFilter, btnCancel}));
		FTFRange.setToolTipText("Upper Bound of your range");
		FTFRange.setHorizontalAlignment(SwingConstants.RIGHT);
		FTFRange.setBounds(180, 106, 55, 20);
		FTFRange.setVisible(false);
		
		contentPane.add(FTFRange);
		DollarSort.setBounds(170, 75, 25, 14);
		
		contentPane.add(DollarSort);
		lblFilterByRetail.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblFilterByRetail.setBounds(82, 11, 270, 28);
		
		contentPane.add(lblFilterByRetail);
		try{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		} catch(ClassNotFoundException e) {
			e.printStackTrace();
		} 
	}
	protected void do_btnCancel_actionPerformed(ActionEvent e) {
		//Cancel will just exit this window instead of all of the frames.
		this.dispose();
	}

	protected void do_comboBox_actionPerformed(ActionEvent e) {
		//All this does is control the visibility of the extra label and field needed for sorting by range
		if (comboBox.getSelectedItem() == "In The Range Of"){
			FTFRange.setVisible(true);
			RangeSort.setVisible(true);
		} else {
			FTFRange.setVisible(false);
			RangeSort.setVisible(false);
		}
	}
	protected void do_btnFilter_actionPerformed(ActionEvent e) {
		//Just set the function to build the query and have it call to Main to run
		String query = "Select * From Inventory Where ";
		if (comboBox.getSelectedItem() == "Less Than"){
			query += "RetailPrice < " + FTFSort.getText();
		} else if (comboBox.getSelectedItem() == "More Than"){
			query += "RetailPrice > " + FTFSort.getText();
		} else if (comboBox.getSelectedItem() == "In The Range Of"){
			query += "RetailPrice >= " + FTFSort.getText() + " And ";
			query += "RetailPrice <= " + FTFRange.getText();
		}
		System.out.println(query);
		

		
		
		this.setVisible(false);
		Inventory Main = new Inventory();
		
		Main.Query(query);
		Main.setVisible(true);
		
		//setting the active state label
		String msg = "";
		if (comboBox.getSelectedItem() == "Less Than"){
			msg += "Retail Price < " + FTFSort.getText();
		} else if (comboBox.getSelectedItem() == "More Than"){
			msg += "Retail Price > " + FTFSort.getText();
		} else if (comboBox.getSelectedItem() == "In The Range Of"){
			msg += "Retail Price >= " + FTFSort.getText() + " And ";
			msg += "Retail Price <= " + FTFRange.getText();
		}
	}
	
}
