import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class layoutsShortcutsFrame extends JFrame {

	private JPanel contentPane;
	private final JLabel lblHey = new JLabel("Hey");
	private final JLabel lblHows = new JLabel("How's");
	private final JLabel lblIt = new JLabel("It");
	private final JLabel lblGoing = new JLabel("Going?");
	private final JButton btnEnable = new JButton("Enable Middle Button");
	private final JButton btnMiddle = new JButton("Hey I'm The Middle Button");
	private final JButton btnDisable = new JButton("Disable Middle Button");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					layoutsShortcutsFrame frame = new layoutsShortcutsFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public layoutsShortcutsFrame() {
		jbInit();
	}
	private void jbInit() {
		setTitle("Aaron Kippins");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblHey.setBounds(107, 41, 46, 14);
		
		contentPane.add(lblHey);
		lblHows.setBounds(107, 96, 46, 14);
		
		contentPane.add(lblHows);
		lblIt.setBounds(107, 151, 46, 14);
		
		contentPane.add(lblIt);
		lblGoing.setBounds(107, 206, 46, 14);
		
		contentPane.add(lblGoing);
		btnEnable.setEnabled(false);
		btnEnable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnEnable_actionPerformed(e);
			}
		});
		btnEnable.setBounds(239, 24, 185, 23);
		
		contentPane.add(btnEnable);
		btnMiddle.setBounds(239, 95, 185, 23);
		
		contentPane.add(btnMiddle);
		btnDisable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnDisable_actionPerformed(e);
			}
		});
		btnDisable.setBounds(239, 166, 185, 23);
		
		contentPane.add(btnDisable);
	}
	
	protected void do_btnEnable_actionPerformed(ActionEvent e) {
		setButtonsStatus();
	}
	protected void do_btnDisable_actionPerformed(ActionEvent e) {
		setButtonsStatus();
	}
	private void setButtonsStatus() {
		btnMiddle.setEnabled(!btnMiddle.isEnabled());
		btnDisable.setEnabled(!btnDisable.isEnabled());
		btnEnable.setEnabled(!btnEnable.isEnabled());
	}
}
