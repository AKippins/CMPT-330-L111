import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;


public class Cycling extends JFrame {

	private JPanel contentPane;
	private final JButton btnClickMe = new JButton("Click Me!");
	private final JLabel lblHello = new JLabel("Hello.");
	private final JLabel lblHowAreYou = new JLabel("How Are You?");
	private final JLabel lblGoodbye = new JLabel("Goodbye");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cycling frame = new Cycling();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Cycling() {
		jbInit();
	}
	private void jbInit() {
		setTitle("Aaron Kippins");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		btnClickMe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_btnClickMe_actionPerformed(arg0);
			}
		});
		btnClickMe.setBounds(172, 197, 89, 23);
		
		contentPane.add(btnClickMe);
		lblHello.setForeground(Color.PINK);
		lblHello.setFont(new Font("Old English Text MT", Font.PLAIN, 25));
		lblHello.setBounds(125, 29, 182, 26);
		
		contentPane.add(lblHello);
		lblHowAreYou.setForeground(Color.CYAN);
		lblHowAreYou.setFont(new Font("Broadway", Font.PLAIN, 25));
		lblHowAreYou.setBounds(125, 86, 182, 26);
		
		contentPane.add(lblHowAreYou);
		lblGoodbye.setForeground(Color.ORANGE);
		lblGoodbye.setFont(new Font("Mistral", Font.PLAIN, 25));
		lblGoodbye.setBounds(125, 144, 182, 31);
		
		contentPane.add(lblGoodbye);
	}
	protected void do_btnClickMe_actionPerformed(ActionEvent arg0) {
		String hello = lblHello.getText();
		lblHello.setText(lblHowAreYou.getText());
		lblHowAreYou.setText(lblGoodbye.getText());
		lblGoodbye.setText(hello);
	}
}
