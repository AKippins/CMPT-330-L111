import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.MaskFormatter;
import javax.swing.JLabel;
import javax.swing.JFormattedTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
//3 formatted text fields when the text field loses focus update letting the user know what field has the highest number

public class MaskEditFrame extends JFrame {

	private JPanel contentPane;
	private final JLabel lblSsn = new JLabel("SSN:");
	private final JFormattedTextField ssnFTF = new JFormattedTextField();
	private final JButton btnShow = new JButton("Show");
	
	//define the SSN mask
	MaskFormatter ssnMask = createFormatter("###-##-####");
	//define the SSN2 mask 
	MaskFormatter ssn2Mask = createFormatter("###-##-####");
	//define the Phone Number Mask
	MaskFormatter phoneNumberMask = createFormatter("(###)-###-####");
	//define the State Mask
	MaskFormatter stateMask = createFormatter("UU");
	
	
	private final JLabel lblShowSsn = new JLabel("");
	private final JLabel lblSsn_1 = new JLabel("SSN2:");
	private final JLabel lblTelephoneNumber = new JLabel("Phone Number:");
	private final JLabel lblState = new JLabel("State:");
	private final JFormattedTextField ssn2FTF = new JFormattedTextField();
	private final JFormattedTextField phoneNumberFTF = new JFormattedTextField();
	private final JFormattedTextField stateFTF = new JFormattedTextField();
	private final JLabel lblShowSsn2 = new JLabel("");
	private final JLabel lblShowPhoneNumber = new JLabel("");
	private final JLabel lblShowState = new JLabel("");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MaskEditFrame frame = new MaskEditFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	//place this code after main()
	public MaskFormatter createFormatter(String s) {
	     MaskFormatter formatter = null;
	     try {
	          formatter = new MaskFormatter(s);
	         } 
	     catch (java.text.ParseException exc) {
		          System.err.println("formatter is bad: " + exc.getMessage());
		          System.exit(-1);
		      }
	      return formatter;
	}//createFormatter

	/**
	 * Create the frame.
	 */
	public MaskEditFrame() {
		jbInit();
	}
	private void jbInit() {
		setTitle("Formatted Text And Mask Edits");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblSsn.setBounds(56, 41, 46, 14);
		
		contentPane.add(lblSsn);
		ssnFTF.setBounds(150, 35, 76, 17);
		ssnMask.setPlaceholderCharacter('_');
		ssnMask.install(ssnFTF);
		
		contentPane.add(ssnFTF);
		btnShow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_btnShow_actionPerformed(arg0);
			}
		});
		btnShow.setBounds(162, 175, 89, 23);
		
		contentPane.add(btnShow);
		lblShowSsn.setBounds(236, 35, 82, 14);
		
		contentPane.add(lblShowSsn);
		lblSsn_1.setBounds(56, 66, 46, 14);
		
		contentPane.add(lblSsn_1);
		lblTelephoneNumber.setBounds(56, 91, 89, 14);
		
		contentPane.add(lblTelephoneNumber);
		lblState.setBounds(56, 116, 46, 14);
		
		contentPane.add(lblState);
		ssn2FTF.setBounds(150, 60, 76, 17);
		ssn2Mask.setPlaceholderCharacter('_');
		ssn2Mask.install(ssn2FTF);

		contentPane.add(ssn2FTF);
		phoneNumberFTF.setBounds(150, 86, 76, 17);
		phoneNumberMask.setPlaceholderCharacter('_');
		phoneNumberMask.install(phoneNumberFTF);
		
		contentPane.add(phoneNumberFTF);
		stateFTF.setBounds(150, 113, 76, 17);
		stateMask.setPlaceholderCharacter('_');
		stateMask.install(stateFTF);
		
		contentPane.add(stateFTF);
		lblShowSsn2.setBounds(236, 60, 46, 14);
		
		contentPane.add(lblShowSsn2);
		lblShowPhoneNumber.setBounds(236, 91, 46, 14);
		
		contentPane.add(lblShowPhoneNumber);
		lblShowState.setBounds(236, 116, 46, 14);
		
		contentPane.add(lblShowState);
	}
	protected void do_btnShow_actionPerformed(ActionEvent arg0) {
		lblShowSsn.setText(ssnFTF.getText());
		lblShowSsn2.setText(ssn2FTF.getText());
		lblShowPhoneNumber.setText(phoneNumberFTF.getText());
		lblShowState.setText(stateFTF.getText());
	}
}
