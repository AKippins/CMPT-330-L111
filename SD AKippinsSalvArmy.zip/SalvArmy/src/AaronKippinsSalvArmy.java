import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.MaskFormatter;
import javax.swing.JTabbedPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFormattedTextField;
import javax.swing.JCheckBox;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;

import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.InputMethodListener;
import java.awt.event.InputMethodEvent;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import java.awt.Font;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;


public class AaronKippinsSalvArmy extends JFrame {

	private JPanel contentPane;
	private final JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
	private final JPanel personalInfo = new JPanel();
	private final JPanel householdInfo = new JPanel();
	private final JPanel financialInfo = new JPanel();
	private final JLabel lblFirstName = new JLabel("First Name:");
	private final JLabel lblLastName = new JLabel("Last Name:");
	private final JLabel lblDateOfBirth = new JLabel("Date Of Birth:");
	private final JLabel lblSocialSecurityNumber = new JLabel("Social Security Number:");
	private final JLabel lblAddress = new JLabel("Address:");
	private final JLabel lblCity = new JLabel("City:");
	private final JLabel lblCounty = new JLabel("County:");
	private final JLabel lblZipCode = new JLabel("Zip Code:");
	private final JLabel lblSpousessName = new JLabel("Spouses's First Name:");
	private final JLabel lblAssistanceThatYou = new JLabel("Assistance That You Are Requesting:");
	private final JLabel lblReferredBy = new JLabel("Referred By:");
	private final JTextField textField = new JTextField();
	private final JTextField textField_1 = new JTextField();
	private final JTextField textField_3 = new JTextField();
	private final JTextField textField_4 = new JTextField();
	private final JTextField textField_7 = new JTextField();
	private final JComboBox comboBox = new JComboBox();
	private final JComboBox comboBox_1 = new JComboBox();
	private final JComboBox comboBox_2 = new JComboBox();
	private final JFormattedTextField formattedTextField = new JFormattedTextField();
	private final JFormattedTextField formattedTextField_1 = new JFormattedTextField();
	private final JLabel lblPhoneNumber = new JLabel("Phone Number:");
	private final JLabel lblSpousessLastName = new JLabel("Spouses's Last Name:");
	private final JTextField textField_6 = new JTextField();
	private final JComboBox comboBox_3 = new JComboBox();
	private final JComboBox comboBox_4 = new JComboBox();
	private final JComboBox comboBox_5 = new JComboBox();
	private final JLabel lblSpousessDob = new JLabel("Spouses's D.O.B.:");
	private final JLabel lblPlaceOfEmployment = new JLabel("Place Of Employment:");
	private final JTextField textField_9 = new JTextField();
	private final JLabel lblSpousessSsn = new JLabel("Spouses's SSN#:");
	private final JLabel lblSpousessPlaceOf = new JLabel("Spouses's Place Of Employment:");
	private final JTextField textField_11 = new JTextField();
	private final JLabel lblIfUnenployedHow = new JLabel("Are You Unemployed?");
	private final JLabel lblIfUnenployedHow_1 = new JLabel("Are You Unemployed?");
	private final JTextField textField_12 = new JTextField();
	private final JTextField textField_13 = new JTextField();
	private final JRadioButton rdbtnYes = new JRadioButton("Yes");
	private final JRadioButton rdbtnNo = new JRadioButton("No");
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final JLabel lblUnemployedForHow = new JLabel("Unemployed for how long?");
	private final JComboBox comboBox_6 = new JComboBox();
	private final JComboBox comboBox_7 = new JComboBox();
	private final JComboBox comboBox_8 = new JComboBox();
	private final JRadioButton radioButton = new JRadioButton("Yes");
	private final JRadioButton radioButton_1 = new JRadioButton("No");
	private final JComboBox comboBox_9 = new JComboBox();
	private final JComboBox comboBox_10 = new JComboBox();
	private final JComboBox comboBox_11 = new JComboBox();
	private final JLabel lblUnemployedForHow_1 = new JLabel("Unemployed for how long?");
	private final ButtonGroup buttonGroup_1 = new ButtonGroup();
	private final JFormattedTextField formattedTextField_2 = new JFormattedTextField();
	private final JFormattedTextField formattedTextField_3 = new JFormattedTextField();
	private final JLabel lblDoesAnyoneElse = new JLabel("Does Anyone Else Live In Your Household Other Than You Or Your Spouse?");
	private final JRadioButton rdbtnYesHouse = new JRadioButton("Yes");
	private final JRadioButton rdbtnNoHouse = new JRadioButton("No");
	private final ButtonGroup buttonGroup_2 = new ButtonGroup();
	private final JLabel lblNewLabel = new JLabel("How Many Others Are There?");
	private final JComboBox comboBox_12 = new JComboBox();
	private final JLabel lblName = new JLabel("Name");
	private final JLabel lblRelationship = new JLabel("Relationship");
	private final JLabel lblAge = new JLabel("Age");
	private final JLabel lblSocialSecurityNumber_1 = new JLabel("Social Security Number");
	private final JLabel label = new JLabel("1.");
	private final JLabel label_1 = new JLabel("2.");
	private final JLabel label_2 = new JLabel("3.");
	private final JLabel label_3 = new JLabel("4.");
	private final JLabel label_4 = new JLabel("5.");
	private final JLabel label_5 = new JLabel("6.");
	private final JTextField textField_2 = new JTextField();
	private final JTextField textField_8 = new JTextField();
	private final JTextField textField_10 = new JTextField();
	private final JTextField textField_14 = new JTextField();
	private final JTextField textField_15 = new JTextField();
	private final JTextField textField_16 = new JTextField();
	private final JComboBox comboBox_13 = new JComboBox();
	private final JComboBox comboBox_14 = new JComboBox();
	private final JComboBox comboBox_15 = new JComboBox();
	private final JComboBox comboBox_16 = new JComboBox();
	private final JComboBox comboBox_17 = new JComboBox();
	private final JComboBox comboBox_18 = new JComboBox();
	private final JFormattedTextField formattedTextField_5 = new JFormattedTextField();
	private final JFormattedTextField formattedTextField_6 = new JFormattedTextField();
	private final JFormattedTextField formattedTextField_7 = new JFormattedTextField();
	private final JFormattedTextField formattedTextField_8 = new JFormattedTextField();
	private final JFormattedTextField formattedTextField_9 = new JFormattedTextField();
	private final JFormattedTextField formattedTextField_10 = new JFormattedTextField();
	private final JComboBox comboBox_19 = new JComboBox();
	private final JComboBox comboBox_20 = new JComboBox();
	private final JComboBox comboBox_21 = new JComboBox();
	private final JComboBox comboBox_22 = new JComboBox();
	private final JComboBox comboBox_23 = new JComboBox();
	private final JComboBox comboBox_24 = new JComboBox();
	private final JLabel lblSalary = new JLabel("Salary:");
	private final JLabel lblSocialSecurity = new JLabel("Social Security:");
	private final JLabel lblUtilityAssistance = new JLabel("Utility Assistance: ");
	private final JLabel lblUnemployment = new JLabel("Unemployment:");
	private final JLabel lblDisablity = new JLabel("Disablity:");
	private final JLabel lblFoodStamps = new JLabel("Food Stamps:");
	private final JLabel lblTanfafdc = new JLabel("TANF/AFDC:");
	private final JLabel lblChildSupport = new JLabel("Child Support:");
	private final JLabel lblOther = new JLabel("Other:");
	private final JLabel lblExplain = new JLabel("Explain:");
	private final JFormattedTextField formattedTextField_4 = new JFormattedTextField();
	private final JFormattedTextField formattedTextField_11 = new JFormattedTextField();
	private final JFormattedTextField formattedTextField_12 = new JFormattedTextField();
	private final JFormattedTextField formattedTextField_13 = new JFormattedTextField();
	private final JFormattedTextField formattedTextField_14 = new JFormattedTextField();
	private final JFormattedTextField formattedTextField_15 = new JFormattedTextField();
	private final JFormattedTextField formattedTextField_16 = new JFormattedTextField();
	private final JFormattedTextField formattedTextField_17 = new JFormattedTextField();
	private final JFormattedTextField formattedTextField_18 = new JFormattedTextField();
	private final JFormattedTextField formattedTextField_19 = new JFormattedTextField();
	private final JLabel lblRent = new JLabel("Rent:");
	private final JLabel lblLightBill = new JLabel("Light Bill:");
	private final JLabel lblCable = new JLabel("Cable:");
	private final JLabel lblPhoneBill = new JLabel("Phone Bill:");
	private final JLabel lblCarPayment = new JLabel("Car Payment:");
	private final JLabel lblMedical = new JLabel("Medical:");
	private final JLabel lblGaswater = new JLabel("Gas/Water:");
	private final JLabel lblFurnitureappliances = new JLabel("Furniture/Appliances:");
	private final JLabel lblOther_1 = new JLabel("Other:");
	private final JLabel lblExplain_1 = new JLabel("Explain:");
	private final JFormattedTextField formattedTextField_20 = new JFormattedTextField();
	private final JFormattedTextField formattedTextField_21 = new JFormattedTextField();
	private final JFormattedTextField formattedTextField_22 = new JFormattedTextField();
	private final JFormattedTextField formattedTextField_23 = new JFormattedTextField();
	private final JFormattedTextField formattedTextField_24 = new JFormattedTextField();
	private final JFormattedTextField formattedTextField_25 = new JFormattedTextField();
	private final JFormattedTextField formattedTextField_26 = new JFormattedTextField();
	private final JFormattedTextField formattedTextField_27 = new JFormattedTextField();
	private final JFormattedTextField formattedTextField_28 = new JFormattedTextField();
	private final JFormattedTextField formattedTextField_29 = new JFormattedTextField();
	private final JLabel lblTotalIncome = new JLabel("Total Income:");
	private final JLabel lblTotalExpenses = new JLabel("Total Expenses:");
	private final JLabel label_6 = new JLabel("");
	private final JLabel label_7 = new JLabel("");
	private final JLabel lblNetIncome = new JLabel("Net Income:");
	private final JLabel label_8 = new JLabel("");
	MaskFormatter mask = createFormatter("###-##-####");
	MaskFormatter mask1 = createFormatter("#####");
	MaskFormatter mask2 = createFormatter("(###)###-####");
	MaskFormatter mask3 = createFormatter("###-##-####");
	MaskFormatter mask4 = createFormatter("$##,###.00");
	MaskFormatter mask5 = createFormatter("###-##-####");
	MaskFormatter mask6 = createFormatter("###-##-####");
	MaskFormatter mask7 = createFormatter("###-##-####");
	MaskFormatter mask8 = createFormatter("###-##-####");
	MaskFormatter mask9 = createFormatter("###-##-####");
	MaskFormatter mask10 = createFormatter("###-##-####");
	MaskFormatter mask11 = createFormatter("$##,###.00");
	MaskFormatter mask12 = createFormatter("$##,###.00");
	MaskFormatter mask13 = createFormatter("$##,###.00");
	MaskFormatter mask14 = createFormatter("$##,###.00");
	MaskFormatter mask15 = createFormatter("$##,###.00");
	MaskFormatter mask16 = createFormatter("$##,###.00");
	MaskFormatter mask17 = createFormatter("$##,###.00");
	MaskFormatter mask18 = createFormatter("$##,###.00");
	MaskFormatter mask19 = createFormatter("$##,###.00");
	MaskFormatter mask20 = createFormatter("$##,###.00");
	MaskFormatter mask21 = createFormatter("$##,###.00");
	MaskFormatter mask22 = createFormatter("$##,###.00");
	MaskFormatter mask23 = createFormatter("$##,###.00");
	MaskFormatter mask24 = createFormatter("$##,###.00");
	MaskFormatter mask25 = createFormatter("$##,###.00");
	MaskFormatter mask26 = createFormatter("$##,###.00");
	MaskFormatter mask27 = createFormatter("$##,###.00");
	MaskFormatter mask28 = createFormatter("$##,###.00");
	MaskFormatter mask29 = createFormatter("$##,###.00");
	private final JComboBox comboBox_25 = new JComboBox();
	private final JLabel lblPresentProblem = new JLabel("Present Problem:");
	private final JTextField textField_5 = new JTextField();
	private final JLabel lblEthnicity = new JLabel("Ethnicity:");
	private final JComboBox comboBox_26 = new JComboBox();
	private final JLabel lblDateOfSubmission = new JLabel("Date Of Submission:");
	private final JComboBox comboBox_27 = new JComboBox();
	private final JComboBox comboBox_28 = new JComboBox();
	private final JComboBox comboBox_29 = new JComboBox();
	private final JSeparator separator = new JSeparator();
	private final JLabel lblIncome = new JLabel("Income");
	private final JLabel lblExpenses = new JLabel("Expenses");
	private final JMenuBar menuBar = new JMenuBar();
	private final JMenu mnFile = new JMenu("File");
	private final JMenu mnHelp = new JMenu("Help");
	private final JMenuItem mntmStartNewApplication = new JMenuItem("Start New Application");
	private final JSeparator separator_1 = new JSeparator();
	private final JMenuItem mntmExit = new JMenuItem("Exit");
	private final JMenuItem mntmPersonal = new JMenuItem("Personal");
	private final JMenuItem mntmHousehold = new JMenuItem("Household");
	private final JMenuItem mntmFinancial = new JMenuItem("Financial");
	
	


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AaronKippinsSalvArmy frame = new AaronKippinsSalvArmy();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	//place this code after main()
	public MaskFormatter createFormatter(String s) {
	     MaskFormatter formatter = null;
	     try {
	          formatter = new MaskFormatter(s);
	         } 
	     catch (java.text.ParseException exc) {
		          System.err.println("formatter is bad: " + exc.getMessage());
		          System.exit(-1);
		      }
	      return formatter;
	}//createFormatter

	/**
	 * Create the frame.
	 */
	public AaronKippinsSalvArmy() {
		textField_5.setBounds(10, 299, 331, 115);
		textField_5.setColumns(10);
		textField_16.setVisible(false);
		textField_16.setText("");
		textField_16.setBounds(108, 278, 86, 20);
		textField_16.setColumns(10);
		textField_15.setVisible(false);
		textField_15.setText("");
		textField_15.setBounds(108, 253, 86, 20);
		textField_15.setColumns(10);
		textField_14.setVisible(false);
		textField_14.setText("");
		textField_14.setBounds(108, 228, 86, 20);
		textField_14.setColumns(10);
		textField_10.setVisible(false);
		textField_10.setText("");
		textField_10.setBounds(108, 203, 86, 20);
		textField_10.setColumns(10);
		textField_8.setVisible(false);
		textField_8.setText("");
		textField_8.setBounds(108, 178, 86, 20);
		textField_8.setColumns(10);
		textField_2.setVisible(false);
		textField_2.setBounds(108, 153, 86, 20);
		textField_2.setColumns(10);
		textField_13.setBounds(543, 308, 192, 20);
		textField_13.setColumns(10);
		textField_12.setBounds(351, 261, 384, 39);
		textField_12.setColumns(10);
		textField_11.setBounds(543, 133, 192, 20);
		textField_11.setColumns(10);
		textField_9.setBounds(145, 258, 192, 20);
		textField_9.setColumns(10);
		textField_6.setBounds(543, 33, 192, 20);
		textField_6.setColumns(10);
		textField_7.setBounds(543, 8, 192, 20);
		textField_7.setColumns(10);
		textField_4.setBounds(145, 158, 192, 20);
		textField_4.setColumns(10);
		textField_3.setBounds(145, 133, 192, 20);
		textField_3.setColumns(10);
		textField_1.setBounds(145, 33, 192, 20);
		textField_1.setColumns(10);
		textField.setBounds(145, 8, 192, 20);
		textField.setColumns(10);
		jbInit();
	}
	private void jbInit() {
		mask.install(formattedTextField);
		mask1.install(formattedTextField_1);
		mask2.install(formattedTextField_2);
		mask3.install(formattedTextField_3);
		mask4.install(formattedTextField_4);
		mask5.install(formattedTextField_5);
		mask6.install(formattedTextField_6);
		mask7.install(formattedTextField_7);
		mask8.install(formattedTextField_8);
		mask9.install(formattedTextField_9);
		mask10.install(formattedTextField_10);
		mask11.install(formattedTextField_11);
		mask12.install(formattedTextField_12);
		mask13.install(formattedTextField_13);
		mask14.install(formattedTextField_14);
		mask15.install(formattedTextField_15);
		mask16.install(formattedTextField_16);
		mask17.install(formattedTextField_17);
		mask18.install(formattedTextField_18);
		mask19.install(formattedTextField_19);
		mask20.install(formattedTextField_20);
		mask21.install(formattedTextField_21);
		mask22.install(formattedTextField_22);
		mask23.install(formattedTextField_23);
		mask24.install(formattedTextField_24);
		mask25.install(formattedTextField_25);
		mask26.install(formattedTextField_26);
		mask27.install(formattedTextField_27);
		mask28.install(formattedTextField_28);
		mask29.install(formattedTextField_29);
		mask.setPlaceholderCharacter('_');
		mask1.setPlaceholderCharacter('_');
		mask2.setPlaceholderCharacter('_');
		mask3.setPlaceholderCharacter('_');
		mask4.setPlaceholderCharacter('0');
		mask5.setPlaceholderCharacter('_');
		mask6.setPlaceholderCharacter('_');
		mask7.setPlaceholderCharacter('_');
		mask8.setPlaceholderCharacter('_');
		mask9.setPlaceholderCharacter('_');
		mask10.setPlaceholderCharacter('_');
		mask11.setPlaceholderCharacter('0');
		mask12.setPlaceholderCharacter('0');
		mask13.setPlaceholderCharacter('0');
		mask14.setPlaceholderCharacter('0');
		mask15.setPlaceholderCharacter('0');
		mask16.setPlaceholderCharacter('0');
		mask17.setPlaceholderCharacter('0');
		mask18.setPlaceholderCharacter('0');
		mask19.setPlaceholderCharacter('0');
		mask20.setPlaceholderCharacter('0');
		mask21.setPlaceholderCharacter('0');
		mask22.setPlaceholderCharacter('0');
		mask23.setPlaceholderCharacter('0');
		mask24.setPlaceholderCharacter('0');
		mask25.setPlaceholderCharacter('0');
		mask26.setPlaceholderCharacter('0');
		mask27.setPlaceholderCharacter('0');
		mask28.setPlaceholderCharacter('0');
		mask29.setPlaceholderCharacter('0');
		
		setTitle("Salvation Army Form");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 774, 516);
		
		setJMenuBar(menuBar);
		
		menuBar.add(mnFile);
		mntmStartNewApplication.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmStartNewApplication_actionPerformed(e);
			}
		});
		
		mnFile.add(mntmStartNewApplication);
		
		mnFile.add(separator_1);
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_mntmExit_actionPerformed(arg0);
			}
		});
		
		mnFile.add(mntmExit);
		
		menuBar.add(mnHelp);
		mntmPersonal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmPersonal_actionPerformed(e);
			}
		});
		
		mnHelp.add(mntmPersonal);
		mntmHousehold.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmHousehold_actionPerformed(e);
			}
		});
		
		mnHelp.add(mntmHousehold);
		mntmFinancial.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmFinancial_actionPerformed(e);
			}
		});
		
		mnHelp.add(mntmFinancial);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		tabbedPane.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
		tabbedPane.setBounds(0, 0, 758, 456);
		
		contentPane.add(tabbedPane);
		
		tabbedPane.addTab("Personal Information", null, personalInfo, null);
		personalInfo.setLayout(null);
		lblFirstName.setBounds(10, 11, 201, 14);
		
		personalInfo.add(lblFirstName);
		lblLastName.setBounds(10, 36, 201, 14);
		
		personalInfo.add(lblLastName);
		lblDateOfBirth.setBounds(10, 61, 201, 14);
		
		personalInfo.add(lblDateOfBirth);
		lblSocialSecurityNumber.setBounds(10, 111, 201, 14);
		
		personalInfo.add(lblSocialSecurityNumber);
		lblAddress.setBounds(10, 136, 201, 14);
		
		personalInfo.add(lblAddress);
		lblCity.setBounds(10, 161, 201, 14);
		
		personalInfo.add(lblCity);
		lblCounty.setBounds(10, 186, 201, 14);
		
		personalInfo.add(lblCounty);
		lblZipCode.setBounds(10, 211, 201, 14);
		
		personalInfo.add(lblZipCode);
		lblSpousessName.setBounds(351, 11, 201, 14);
		
		personalInfo.add(lblSpousessName);
		lblAssistanceThatYou.setBounds(351, 236, 244, 14);
		
		personalInfo.add(lblAssistanceThatYou);
		lblReferredBy.setBounds(351, 311, 201, 14);
		
		personalInfo.add(lblReferredBy);
		
		personalInfo.add(textField);
		
		personalInfo.add(textField_1);
		
		personalInfo.add(textField_3);
		
		personalInfo.add(textField_4);
		
		personalInfo.add(textField_7);
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"January", "Febuary", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}));
		comboBox.setBounds(145, 58, 76, 20);
		
		personalInfo.add(comboBox);
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		comboBox_1.setBounds(231, 58, 37, 20);
		
		personalInfo.add(comboBox_1);
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990", "1989", "1988", "1987", "1986", "1985", "1984", "1983", "1982", "1981", "1980", "1979", "1978", "1977", "1976", "1975", "1974", "1973", "1972", "1971", "1970", "1969", "1968", "1967", "1966", "1965", "1964", "1963", "1962", "1961", "1960", "1959", "1958", "1957", "1956", "1955", "1954", "1953", "1952", "1951", "1950", "1949", "1948", "1947", "1946", "1945", "1944", "1943", "1942", "1941", "1940", "1939", "1938", "1937", "1936", "1935", "1934", "1933", "1932", "1931", "1930", "1929", "1928", "1927", "1926", "1925", "1924", "1923", "1922", "1921", "1920", "1919", "1918", "1917", "1916", "1915", "1914", "1913", "1912", "1911", "1910", "1909", "1908", "1907", "1906", "1905", "1904", "1903", "1902", "1901", "1900"}));
		comboBox_2.setBounds(278, 58, 59, 20);
		
		personalInfo.add(comboBox_2);
		formattedTextField.setBounds(165, 108, 172, 20);
		formattedTextField.setText("");
		
		personalInfo.add(formattedTextField);
		formattedTextField_1.setBounds(145, 208, 192, 20);
		formattedTextField_1.setText("");
		
		personalInfo.add(formattedTextField_1);
		lblPhoneNumber.setBounds(10, 86, 201, 14);
		
		personalInfo.add(lblPhoneNumber);
		lblSpousessLastName.setBounds(351, 36, 201, 14);
		
		personalInfo.add(lblSpousessLastName);
		
		personalInfo.add(textField_6);
		comboBox_3.setModel(new DefaultComboBoxModel(new String[] {"January", "Febuary", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}));
		comboBox_3.setBounds(543, 58, 76, 20);
		
		personalInfo.add(comboBox_3);
		comboBox_4.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		comboBox_4.setBounds(629, 58, 37, 20);
		
		personalInfo.add(comboBox_4);
		comboBox_5.setModel(new DefaultComboBoxModel(new String[] {"2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990", "1989", "1988", "1987", "1986", "1985", "1984", "1983", "1982", "1981", "1980", "1979", "1978", "1977", "1976", "1975", "1974", "1973", "1972", "1971", "1970", "1969", "1968", "1967", "1966", "1965", "1964", "1963", "1962", "1961", "1960", "1959", "1958", "1957", "1956", "1955", "1954", "1953", "1952", "1951", "1950", "1949", "1948", "1947", "1946", "1945", "1944", "1943", "1942", "1941", "1940", "1939", "1938", "1937", "1936", "1935", "1934", "1933", "1932", "1931", "1930", "1929", "1928", "1927", "1926", "1925", "1924", "1923", "1922", "1921", "1920", "1919", "1918", "1917", "1916", "1915", "1914", "1913", "1912", "1911", "1910", "1909", "1908", "1907", "1906", "1905", "1904", "1903", "1902", "1901", "1900"}));
		comboBox_5.setBounds(676, 58, 59, 20);
		
		personalInfo.add(comboBox_5);
		lblSpousessDob.setBounds(351, 61, 201, 14);
		
		personalInfo.add(lblSpousessDob);
		lblPlaceOfEmployment.setBounds(10, 261, 172, 14);
		lblPlaceOfEmployment.setVisible(false);
		
		personalInfo.add(lblPlaceOfEmployment);
		textField_9.setVisible(false);
		
		personalInfo.add(textField_9);
		lblSpousessSsn.setBounds(351, 86, 201, 14);
		
		personalInfo.add(lblSpousessSsn);
		lblSpousessPlaceOf.setBounds(351, 136, 201, 14);
		lblSpousessPlaceOf.setVisible(false);
		
		personalInfo.add(lblSpousessPlaceOf);
		textField_11.setVisible(false);
		
		personalInfo.add(textField_11);
		lblIfUnenployedHow.setBounds(10, 236, 172, 14);
		
		personalInfo.add(lblIfUnenployedHow);
		lblIfUnenployedHow_1.setBounds(351, 111, 201, 14);
		
		personalInfo.add(lblIfUnenployedHow_1);
		
		personalInfo.add(textField_12);
		
		personalInfo.add(textField_13);
		buttonGroup.add(rdbtnYes);
		rdbtnYes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnYes_actionPerformed(e);
			}
		});
		rdbtnYes.setBounds(145, 232, 109, 23);
		
		personalInfo.add(rdbtnYes);
		buttonGroup.add(rdbtnNo);
		rdbtnNo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnNo_actionPerformed(e);
			}
		});
		rdbtnNo.setBounds(256, 232, 81, 23);
		
		personalInfo.add(rdbtnNo);
		lblUnemployedForHow.setBounds(10, 261, 178, 14);
		lblUnemployedForHow.setVisible(false);
		
		personalInfo.add(lblUnemployedForHow);
		comboBox_6.setModel(new DefaultComboBoxModel(new String[] {"dd", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30"}));
		comboBox_6.setBounds(175, 258, 46, 20);
		comboBox_6.setVisible(false);
		
		personalInfo.add(comboBox_6);
		comboBox_7.setModel(new DefaultComboBoxModel(new String[] {"mm", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11"}));
		comboBox_7.setBounds(231, 258, 50, 20);
		comboBox_7.setVisible(false);
		
		personalInfo.add(comboBox_7);
		comboBox_8.setModel(new DefaultComboBoxModel(new String[] {"yy", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30"}));
		comboBox_8.setBounds(291, 258, 46, 20);
		comboBox_8.setVisible(false);
		
		personalInfo.add(comboBox_8);
		buttonGroup_1.add(radioButton);
		radioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_radioButton_actionPerformed(e);
			}
		});
		radioButton.setBounds(543, 107, 109, 23);
		
		personalInfo.add(radioButton);
		buttonGroup_1.add(radioButton_1);
		radioButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_radioButton_1_actionPerformed(e);
			}
		});
		radioButton_1.setBounds(654, 107, 109, 23);
		
		personalInfo.add(radioButton_1);
		comboBox_9.setModel(new DefaultComboBoxModel(new String[] {"dd", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30"}));
		comboBox_9.setBounds(553, 133, 46, 20);
		comboBox_9.setVisible(false);
		
		personalInfo.add(comboBox_9);
		comboBox_10.setModel(new DefaultComboBoxModel(new String[] {"mm", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11"}));
		comboBox_10.setBounds(611, 133, 55, 20);
		comboBox_10.setVisible(false);
		
		personalInfo.add(comboBox_10);
		comboBox_11.setModel(new DefaultComboBoxModel(new String[] {"yy", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30"}));
		comboBox_11.setBounds(685, 133, 50, 20);
		comboBox_11.setVisible(false);
		
		personalInfo.add(comboBox_11);
		lblUnemployedForHow_1.setBounds(351, 136, 192, 14);
		lblUnemployedForHow_1.setVisible(false);
		
		personalInfo.add(lblUnemployedForHow_1);
		formattedTextField_2.setBounds(145, 83, 192, 20);
		formattedTextField_2.setText("");
		
		personalInfo.add(formattedTextField_2);
		formattedTextField_3.setBounds(543, 83, 192, 20);
		formattedTextField_3.setText("");
		
		personalInfo.add(formattedTextField_3);
		comboBox_25.setModel(new DefaultComboBoxModel(new String[] {"", "Albany", "Allegany", "Bronx", "Broome", "Cattaraugus", "Cayuga", "Chautauqua", "Chemung", "Chenango", "Clinton", "Columbia", "Cortland", "Delaware", "Dutchess", "Erie", "Essex", "Franklin", "Fulton", "Genesee", "Greene", "Hamilton", "Herkimer", "Jefferson", "Kings", "Lewis", "Livingston", "Madison", "Monroe", "Montgomery", "Nassau", "New York", "Niagara", "Oneida", "Onondaga", "Ontario", "Orange", "Orleans", "Oswego", "Otsego", "Putnam", "Queens", "Rensselaer", "Richmond", "Rockland", "Saratoga", "Schenectady", "Schoharie", "Schuyler", "Seneca", "St Lawrence", "Steuben", "Suffolk", "Sullivan", "Tioga", "Tompkins", "Ulster", "Warren", "Washington", "Wayne", "Westchester", "Wyoming", "Yates"}));
		comboBox_25.setBounds(145, 183, 192, 20);
		
		personalInfo.add(comboBox_25);
		lblPresentProblem.setBounds(10, 286, 172, 14);
		
		personalInfo.add(lblPresentProblem);
		
		personalInfo.add(textField_5);
		lblEthnicity.setBounds(351, 161, 109, 14);
		
		personalInfo.add(lblEthnicity);
		comboBox_26.setModel(new DefaultComboBoxModel(new String[] {"White", "Black", "Hispanic", "Asian", "American Indian", "Other"}));
		comboBox_26.setBounds(543, 158, 192, 20);
		
		personalInfo.add(comboBox_26);
		lblDateOfSubmission.setBounds(351, 336, 178, 14);
		
		personalInfo.add(lblDateOfSubmission);
		comboBox_27.setModel(new DefaultComboBoxModel(new String[] {"January", "Febuary", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}));
		comboBox_27.setBounds(543, 333, 76, 20);
		
		personalInfo.add(comboBox_27);
		comboBox_28.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		comboBox_28.setBounds(629, 333, 37, 20);
		
		personalInfo.add(comboBox_28);
		comboBox_29.setModel(new DefaultComboBoxModel(new String[] {"2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990", "1989", "1988", "1987", "1986", "1985", "1984", "1983", "1982", "1981", "1980", "1979", "1978", "1977", "1976", "1975", "1974", "1973", "1972", "1971", "1970", "1969", "1968", "1967", "1966", "1965", "1964", "1963", "1962", "1961", "1960", "1959", "1958", "1957", "1956", "1955", "1954", "1953", "1952", "1951", "1950", "1949", "1948", "1947", "1946", "1945", "1944", "1943", "1942", "1941", "1940", "1939", "1938", "1937", "1936", "1935", "1934", "1933", "1932", "1931", "1930", "1929", "1928", "1927", "1926", "1925", "1924", "1923", "1922", "1921", "1920", "1919", "1918", "1917", "1916", "1915", "1914", "1913", "1912", "1911", "1910", "1909", "1908", "1907", "1906", "1905", "1904", "1903", "1902", "1901", "1900"}));
		comboBox_29.setBounds(676, 333, 59, 20);
		
		personalInfo.add(comboBox_29);
		
		tabbedPane.addTab("Household Information", null, householdInfo, null);
		householdInfo.setLayout(null);
		lblDoesAnyoneElse.setBounds(182, 11, 441, 14);
		
		householdInfo.add(lblDoesAnyoneElse);
		buttonGroup_2.add(rdbtnYesHouse);
		rdbtnYesHouse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnYesHouse_actionPerformed(e);
			}
		});
		rdbtnYesHouse.setBounds(255, 32, 109, 23);
		
		householdInfo.add(rdbtnYesHouse);
		buttonGroup_2.add(rdbtnNoHouse);
		rdbtnNoHouse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnNoHouse_actionPerformed(e);
			}
		});
		rdbtnNoHouse.setBounds(372, 32, 109, 23);
		
		householdInfo.add(rdbtnNoHouse);
		lblNewLabel.setBounds(298, 76, 170, 14);
		lblNewLabel.setVisible(false);
		
		householdInfo.add(lblNewLabel);
		comboBox_12.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				do_comboBox_12_itemStateChanged(arg0);
			}
		});
		
		comboBox_12.setModel(new DefaultComboBoxModel(new String[] {"?", "1", "2", "3", "4", "5", "6"}));
		comboBox_12.setBounds(344, 101, 56, 20);
		comboBox_12.setVisible(false);
		
		householdInfo.add(comboBox_12);
		lblName.setVisible(false);
		lblName.setBounds(133, 132, 46, 14);
		
		householdInfo.add(lblName);
		lblRelationship.setVisible(false);
		lblRelationship.setBounds(257, 132, 81, 14);
		
		householdInfo.add(lblRelationship);
		lblAge.setVisible(false);
		lblAge.setBounds(392, 132, 46, 14);
		
		householdInfo.add(lblAge);
		lblSocialSecurityNumber_1.setVisible(false);
		lblSocialSecurityNumber_1.setBounds(493, 132, 160, 14);
		
		householdInfo.add(lblSocialSecurityNumber_1);
		label.setVisible(false);
		label.setBounds(78, 156, 46, 14);
		
		householdInfo.add(label);
		label_1.setVisible(false);
		label_1.setBounds(78, 181, 46, 14);
		
		householdInfo.add(label_1);
		label_2.setVisible(false);
		label_2.setBounds(78, 206, 46, 14);
		
		householdInfo.add(label_2);
		label_3.setVisible(false);
		label_3.setBounds(78, 231, 46, 14);
		
		householdInfo.add(label_3);
		label_4.setVisible(false);
		label_4.setBounds(78, 256, 46, 14);
		
		householdInfo.add(label_4);
		label_5.setVisible(false);
		label_5.setBounds(78, 281, 46, 14);
		
		householdInfo.add(label_5);
		
		householdInfo.add(textField_2);
		
		householdInfo.add(textField_8);
		
		householdInfo.add(textField_10);
		
		householdInfo.add(textField_14);
		
		householdInfo.add(textField_15);
		
		householdInfo.add(textField_16);
		comboBox_13.setVisible(false);
		comboBox_13.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99"}));
		comboBox_13.setBounds(374, 153, 56, 20);
		
		householdInfo.add(comboBox_13);
		comboBox_14.setVisible(false);
		comboBox_14.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99"}));
		comboBox_14.setBounds(374, 178, 56, 20);
		
		householdInfo.add(comboBox_14);
		comboBox_15.setVisible(false);
		comboBox_15.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99"}));
		comboBox_15.setBounds(374, 203, 56, 20);
		
		householdInfo.add(comboBox_15);
		comboBox_16.setVisible(false);
		comboBox_16.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99"}));
		comboBox_16.setBounds(374, 228, 56, 20);
		
		householdInfo.add(comboBox_16);
		comboBox_17.setVisible(false);
		comboBox_17.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99"}));
		comboBox_17.setBounds(374, 253, 56, 20);
		
		householdInfo.add(comboBox_17);
		comboBox_18.setVisible(false);
		comboBox_18.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99"}));
		comboBox_18.setBounds(374, 278, 56, 20);
		
		householdInfo.add(comboBox_18);
		formattedTextField_5.setVisible(false);
		formattedTextField_5.setText("");
		formattedTextField_5.setBounds(483, 178, 129, 20);
		
		householdInfo.add(formattedTextField_5);
		formattedTextField_6.setVisible(false);
		formattedTextField_6.setText("");
		formattedTextField_6.setBounds(483, 203, 129, 20);
		
		householdInfo.add(formattedTextField_6);
		formattedTextField_7.setVisible(false);
		formattedTextField_7.setText("");
		formattedTextField_7.setBounds(483, 228, 129, 20);
		
		householdInfo.add(formattedTextField_7);
		formattedTextField_8.setVisible(false);
		formattedTextField_8.setText("");
		formattedTextField_8.setBounds(483, 253, 129, 20);
		
		householdInfo.add(formattedTextField_8);
		formattedTextField_9.setVisible(false);
		formattedTextField_9.setText("");
		formattedTextField_9.setBounds(483, 278, 129, 20);
		
		householdInfo.add(formattedTextField_9);
		formattedTextField_10.setVisible(false);
		formattedTextField_10.setText("");
		formattedTextField_10.setBounds(483, 153, 129, 20);
		
		householdInfo.add(formattedTextField_10);
		comboBox_19.setVisible(false);
		comboBox_19.setModel(new DefaultComboBoxModel(new String[] {"Child ", "Grandchild", "Sibling", "Parent", "Grandparent", "Extended Family", "Other"}));
		comboBox_19.setBounds(229, 153, 109, 20);
		
		householdInfo.add(comboBox_19);
		comboBox_20.setVisible(false);
		comboBox_20.setModel(new DefaultComboBoxModel(new String[] {"Child ", "Grandchild", "Sibling", "Parent", "Grandparent", "Extended Family", "Other"}));
		comboBox_20.setBounds(229, 178, 109, 20);
		
		householdInfo.add(comboBox_20);
		comboBox_21.setVisible(false);
		comboBox_21.setModel(new DefaultComboBoxModel(new String[] {"Child ", "Grandchild", "Sibling", "Parent", "Grandparent", "Extended Family", "Other"}));
		comboBox_21.setBounds(229, 203, 109, 20);
		
		householdInfo.add(comboBox_21);
		comboBox_22.setVisible(false);
		comboBox_22.setModel(new DefaultComboBoxModel(new String[] {"Child ", "Grandchild", "Sibling", "Parent", "Grandparent", "Extended Family", "Other"}));
		comboBox_22.setBounds(229, 228, 109, 20);
		
		householdInfo.add(comboBox_22);
		comboBox_23.setVisible(false);
		comboBox_23.setModel(new DefaultComboBoxModel(new String[] {"Child ", "Grandchild", "Sibling", "Parent", "Grandparent", "Extended Family", "Other"}));
		comboBox_23.setBounds(229, 253, 109, 20);
		
		householdInfo.add(comboBox_23);
		comboBox_24.setVisible(false);
		comboBox_24.setModel(new DefaultComboBoxModel(new String[] {"Child ", "Grandchild", "Sibling", "Parent", "Grandparent", "Extended Family", "Other"}));
		comboBox_24.setBounds(229, 278, 109, 20);
		
		householdInfo.add(comboBox_24);
		
		tabbedPane.addTab("Financial Information", null, financialInfo, null);
		financialInfo.setLayout(null);
		lblSalary.setBounds(26, 68, 117, 14);
		
		financialInfo.add(lblSalary);
		lblSocialSecurity.setBounds(26, 93, 117, 14);
		
		financialInfo.add(lblSocialSecurity);
		lblUtilityAssistance.setBounds(26, 117, 117, 14);
		
		financialInfo.add(lblUtilityAssistance);
		lblUnemployment.setBounds(26, 142, 117, 14);
		
		financialInfo.add(lblUnemployment);
		lblDisablity.setBounds(26, 167, 117, 14);
		
		financialInfo.add(lblDisablity);
		lblFoodStamps.setBounds(26, 192, 117, 14);
		
		financialInfo.add(lblFoodStamps);
		lblTanfafdc.setBounds(26, 217, 117, 14);
		
		financialInfo.add(lblTanfafdc);
		lblChildSupport.setBounds(26, 242, 117, 14);
		
		financialInfo.add(lblChildSupport);
		lblOther.setBounds(26, 267, 117, 14);
		
		financialInfo.add(lblOther);
		lblExplain.setBounds(26, 292, 117, 14);
		
		financialInfo.add(lblExplain);
		formattedTextField_4.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent arg0) {
				do_formattedTextField_4_focusLost(arg0);
			}
		});
		formattedTextField_4.setHorizontalAlignment(SwingConstants.RIGHT);
		formattedTextField_4.setText("0");
		formattedTextField_4.setBounds(139, 65, 97, 20);
		
		financialInfo.add(formattedTextField_4);
		formattedTextField_11.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_formattedTextField_11_focusLost(e);
			}
		});
		formattedTextField_11.setHorizontalAlignment(SwingConstants.RIGHT);
		formattedTextField_11.setText("0");
		formattedTextField_11.setBounds(139, 90, 97, 20);
		
		financialInfo.add(formattedTextField_11);
		formattedTextField_12.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_formattedTextField_12_focusLost(e);
			}
		});
		formattedTextField_12.setHorizontalAlignment(SwingConstants.RIGHT);
		formattedTextField_12.setText("0");
		formattedTextField_12.setBounds(139, 114, 97, 20);
		
		financialInfo.add(formattedTextField_12);
		formattedTextField_13.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_formattedTextField_13_focusLost(e);
			}
		});
		formattedTextField_13.setHorizontalAlignment(SwingConstants.RIGHT);
		formattedTextField_13.setText("0");
		formattedTextField_13.setBounds(139, 139, 97, 20);
		
		financialInfo.add(formattedTextField_13);
		formattedTextField_14.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_formattedTextField_14_focusLost(e);
			}
		});
		formattedTextField_14.setHorizontalAlignment(SwingConstants.RIGHT);
		formattedTextField_14.setText("0");
		formattedTextField_14.setBounds(139, 164, 97, 20);
		
		financialInfo.add(formattedTextField_14);
		formattedTextField_15.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_formattedTextField_15_focusLost(e);
			}
		});
		formattedTextField_15.setHorizontalAlignment(SwingConstants.RIGHT);
		formattedTextField_15.setText("0");
		formattedTextField_15.setBounds(139, 189, 97, 20);
		
		financialInfo.add(formattedTextField_15);
		formattedTextField_16.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_formattedTextField_16_focusLost(e);
			}
		});
		formattedTextField_16.setHorizontalAlignment(SwingConstants.RIGHT);
		formattedTextField_16.setText("0");
		formattedTextField_16.setBounds(139, 214, 97, 20);
		
		financialInfo.add(formattedTextField_16);
		formattedTextField_17.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_formattedTextField_17_focusLost(e);
			}
		});
		formattedTextField_17.setHorizontalAlignment(SwingConstants.RIGHT);
		formattedTextField_17.setText("0");
		formattedTextField_17.setBounds(139, 239, 97, 20);
		
		financialInfo.add(formattedTextField_17);
		formattedTextField_18.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_formattedTextField_18_focusLost(e);
			}
		});
		formattedTextField_18.setHorizontalAlignment(SwingConstants.RIGHT);
		formattedTextField_18.setText("0");
		formattedTextField_18.setBounds(139, 264, 97, 20);
		
		financialInfo.add(formattedTextField_18);
		formattedTextField_19.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_formattedTextField_19_focusLost(e);
			}
		});
		formattedTextField_19.setHorizontalAlignment(SwingConstants.RIGHT);
		formattedTextField_19.setText("0");
		formattedTextField_19.setBounds(139, 289, 97, 20);
		
		financialInfo.add(formattedTextField_19);
		lblRent.setBounds(310, 68, 149, 14);
		
		financialInfo.add(lblRent);
		lblLightBill.setBounds(310, 93, 149, 14);
		
		financialInfo.add(lblLightBill);
		lblCable.setBounds(310, 117, 149, 14);
		
		financialInfo.add(lblCable);
		lblPhoneBill.setBounds(310, 142, 149, 14);
		
		financialInfo.add(lblPhoneBill);
		lblCarPayment.setBounds(310, 167, 149, 14);
		
		financialInfo.add(lblCarPayment);
		lblMedical.setBounds(310, 192, 149, 14);
		
		financialInfo.add(lblMedical);
		lblGaswater.setBounds(310, 217, 149, 14);
		
		financialInfo.add(lblGaswater);
		lblFurnitureappliances.setBounds(310, 242, 149, 14);
		
		financialInfo.add(lblFurnitureappliances);
		lblOther_1.setBounds(310, 267, 149, 14);
		
		financialInfo.add(lblOther_1);
		lblExplain_1.setBounds(310, 292, 149, 14);
		
		financialInfo.add(lblExplain_1);
		formattedTextField_20.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_formattedTextField_20_focusLost(e);
			}
		});
		formattedTextField_20.setHorizontalAlignment(SwingConstants.RIGHT);
		formattedTextField_20.setForeground(Color.RED);
		formattedTextField_20.setText("0");
		formattedTextField_20.setBounds(453, 65, 97, 20);
		
		financialInfo.add(formattedTextField_20);
		formattedTextField_21.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_formattedTextField_21_focusLost(e);
			}
		});
		formattedTextField_21.setHorizontalAlignment(SwingConstants.RIGHT);
		formattedTextField_21.setForeground(Color.RED);
		formattedTextField_21.setText("0");
		formattedTextField_21.setBounds(453, 90, 97, 20);
		
		financialInfo.add(formattedTextField_21);
		formattedTextField_22.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_formattedTextField_22_focusLost(e);
			}
		});
		formattedTextField_22.setHorizontalAlignment(SwingConstants.RIGHT);
		formattedTextField_22.setForeground(Color.RED);
		formattedTextField_22.setText("0");
		formattedTextField_22.setBounds(453, 114, 97, 20);
		
		financialInfo.add(formattedTextField_22);
		formattedTextField_23.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_formattedTextField_23_focusLost(e);
			}
		});
		formattedTextField_23.setHorizontalAlignment(SwingConstants.RIGHT);
		formattedTextField_23.setForeground(Color.RED);
		formattedTextField_23.setText("0");
		formattedTextField_23.setBounds(453, 139, 97, 20);
		
		financialInfo.add(formattedTextField_23);
		formattedTextField_24.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_formattedTextField_24_focusLost(e);
			}
		});
		formattedTextField_24.setHorizontalAlignment(SwingConstants.RIGHT);
		formattedTextField_24.setForeground(Color.RED);
		formattedTextField_24.setText("0");
		formattedTextField_24.setBounds(453, 164, 97, 20);
		
		financialInfo.add(formattedTextField_24);
		formattedTextField_25.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_formattedTextField_25_focusLost(e);
			}
		});
		formattedTextField_25.setHorizontalAlignment(SwingConstants.RIGHT);
		formattedTextField_25.setForeground(Color.RED);
		formattedTextField_25.setText("0");
		formattedTextField_25.setBounds(453, 189, 97, 20);
		
		financialInfo.add(formattedTextField_25);
		formattedTextField_26.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_formattedTextField_26_focusLost(e);
			}
		});
		formattedTextField_26.setHorizontalAlignment(SwingConstants.RIGHT);
		formattedTextField_26.setForeground(Color.RED);
		formattedTextField_26.setText("0");
		formattedTextField_26.setBounds(453, 214, 97, 20);
		
		financialInfo.add(formattedTextField_26);
		formattedTextField_27.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_formattedTextField_27_focusLost(e);
			}
		});
		formattedTextField_27.setHorizontalAlignment(SwingConstants.RIGHT);
		formattedTextField_27.setForeground(Color.RED);
		formattedTextField_27.setText("0");
		formattedTextField_27.setBounds(453, 239, 97, 20);
		
		financialInfo.add(formattedTextField_27);
		formattedTextField_28.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_formattedTextField_28_focusLost(e);
			}
		});
		formattedTextField_28.setHorizontalAlignment(SwingConstants.RIGHT);
		formattedTextField_28.setForeground(Color.RED);
		formattedTextField_28.setText("0");
		formattedTextField_28.setBounds(453, 264, 97, 20);
		
		financialInfo.add(formattedTextField_28);
		formattedTextField_29.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				do_formattedTextField_29_focusLost(e);
			}
		});
		formattedTextField_29.setHorizontalAlignment(SwingConstants.RIGHT);
		formattedTextField_29.setForeground(Color.RED);
		formattedTextField_29.setText("0");
		formattedTextField_29.setBounds(453, 289, 97, 20);
		
		financialInfo.add(formattedTextField_29);
		lblTotalIncome.setBounds(26, 342, 149, 14);
		
		financialInfo.add(lblTotalIncome);
		lblTotalExpenses.setBounds(310, 342, 149, 14);
		
		financialInfo.add(lblTotalExpenses);
		label_6.setBounds(139, 342, 149, 14);
		
		financialInfo.add(label_6);
		label_7.setBounds(453, 342, 149, 14);
		
		financialInfo.add(label_7);
		lblNetIncome.setBounds(209, 398, 149, 14);
		
		financialInfo.add(lblNetIncome);
		label_8.setBounds(335, 398, 164, 14);
		
		financialInfo.add(label_8);
		separator.setOrientation(SwingConstants.VERTICAL);
		separator.setBounds(275, 41, 2, 290);
		
		financialInfo.add(separator);
		lblIncome.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblIncome.setBounds(26, 11, 149, 20);
		
		financialInfo.add(lblIncome);
		lblExpenses.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblExpenses.setBounds(310, 11, 149, 20);
		
		financialInfo.add(lblExpenses);
	}
	protected void do_rdbtnYes_actionPerformed(ActionEvent e) {
		lblPlaceOfEmployment.setVisible(true);
		textField_9.setVisible(true);
		lblUnemployedForHow.setVisible(false);
		comboBox_6.setVisible(false);
		comboBox_7.setVisible(false);
		comboBox_8.setVisible(false);
	}
	protected void do_rdbtnNo_actionPerformed(ActionEvent e) {
		lblUnemployedForHow.setVisible(true);
		comboBox_6.setVisible(true);
		comboBox_7.setVisible(true);
		comboBox_8.setVisible(true);
		lblPlaceOfEmployment.setVisible(false);
		textField_9.setVisible(false);
		
	}
	protected void do_radioButton_actionPerformed(ActionEvent e) {
		lblUnemployedForHow_1.setVisible(true);
		comboBox_9.setVisible(true);
		comboBox_10.setVisible(true);
		comboBox_11.setVisible(true);
		lblSpousessPlaceOf.setVisible(false);
		textField_11.setVisible(false);
	}
	protected void do_radioButton_1_actionPerformed(ActionEvent e) {
		lblUnemployedForHow_1.setVisible(false);
		comboBox_9.setVisible(false);
		comboBox_10.setVisible(false);
		comboBox_11.setVisible(false);
		lblSpousessPlaceOf.setVisible(true);
		textField_11.setVisible(true);
	}
	protected void do_rdbtnYesHouse_actionPerformed(ActionEvent e) {
		lblNewLabel.setVisible(true);
		comboBox_12.setVisible(true);
	}
	protected void do_rdbtnNoHouse_actionPerformed(ActionEvent e) {
		lblNewLabel.setVisible(false);
		comboBox_12.setVisible(false);
		lblName.setVisible(false);
		lblAge.setVisible(false);
		lblRelationship.setVisible(false);
		lblSocialSecurityNumber_1.setVisible(false);
		label.setVisible(false);
		label_1.setVisible(false);
		label_2.setVisible(false);
		label_3.setVisible(false);
		label_4.setVisible(false);
		label_5.setVisible(false);
		textField_2.setVisible(false);
		textField_8.setVisible(false);
		textField_10.setVisible(false);
		textField_14.setVisible(false);
		textField_15.setVisible(false);
		textField_16.setVisible(false);
		comboBox_13.setVisible(false);
		comboBox_14.setVisible(false);
		comboBox_15.setVisible(false);
		comboBox_16.setVisible(false);
		comboBox_17.setVisible(false);
		comboBox_18.setVisible(false);
		comboBox_19.setVisible(false);
		comboBox_20.setVisible(false);
		comboBox_21.setVisible(false);
		comboBox_22.setVisible(false);
		comboBox_23.setVisible(false);
		comboBox_24.setVisible(false);
		formattedTextField_5.setVisible(false);
		formattedTextField_6.setVisible(false);
		formattedTextField_7.setVisible(false);
		formattedTextField_8.setVisible(false);
		formattedTextField_9.setVisible(false);
		formattedTextField_10.setVisible(false);
	}
	
	protected void do_comboBox_12_itemStateChanged(ItemEvent arg0) {
		if (comboBox_12.getSelectedItem() == "?"){
			lblName.setVisible(false);
			lblAge.setVisible(false);
			lblRelationship.setVisible(false);
			lblSocialSecurityNumber_1.setVisible(false);
			label.setVisible(false);
			label_1.setVisible(false);
			label_2.setVisible(false);
			label_3.setVisible(false);
			label_4.setVisible(false);
			label_5.setVisible(false);
			textField_2.setVisible(false);
			textField_8.setVisible(false);
			textField_10.setVisible(false);
			textField_14.setVisible(false);
			textField_15.setVisible(false);
			textField_16.setVisible(false);
			comboBox_13.setVisible(false);
			comboBox_14.setVisible(false);
			comboBox_15.setVisible(false);
			comboBox_16.setVisible(false);
			comboBox_17.setVisible(false);
			comboBox_18.setVisible(false);
			comboBox_19.setVisible(false);
			comboBox_20.setVisible(false);
			comboBox_21.setVisible(false);
			comboBox_22.setVisible(false);
			comboBox_23.setVisible(false);
			comboBox_24.setVisible(false);
			formattedTextField_5.setVisible(false);
			formattedTextField_6.setVisible(false);
			formattedTextField_7.setVisible(false);
			formattedTextField_8.setVisible(false);
			formattedTextField_9.setVisible(false);
			formattedTextField_10.setVisible(false);
		}
		if (comboBox_12.getSelectedItem() == "1"){
			lblName.setVisible(true);
			lblAge.setVisible(true);
			lblRelationship.setVisible(true);
			lblSocialSecurityNumber_1.setVisible(true);
			label.setVisible(true);
			label_1.setVisible(false);
			label_2.setVisible(false);
			label_3.setVisible(false);
			label_4.setVisible(false);
			label_5.setVisible(false);
			textField_2.setVisible(true);
			textField_8.setVisible(false);
			textField_10.setVisible(false);
			textField_14.setVisible(false);
			textField_15.setVisible(false);
			textField_16.setVisible(false);
			comboBox_13.setVisible(true);
			comboBox_14.setVisible(false);
			comboBox_15.setVisible(false);
			comboBox_16.setVisible(false);
			comboBox_17.setVisible(false);
			comboBox_18.setVisible(false);
			comboBox_19.setVisible(true);
			comboBox_20.setVisible(false);
			comboBox_21.setVisible(false);
			comboBox_22.setVisible(false);
			comboBox_23.setVisible(false);
			comboBox_24.setVisible(false);
			formattedTextField_5.setVisible(false);
			formattedTextField_6.setVisible(false);
			formattedTextField_7.setVisible(false);
			formattedTextField_8.setVisible(false);
			formattedTextField_9.setVisible(false);
			formattedTextField_10.setVisible(true);
		}
		if (comboBox_12.getSelectedItem() == "2"){
			lblName.setVisible(true);
			lblAge.setVisible(true);
			lblRelationship.setVisible(true);
			lblSocialSecurityNumber_1.setVisible(true);
			label.setVisible(true);
			label_1.setVisible(true);
			label_2.setVisible(false);
			label_3.setVisible(false);
			label_4.setVisible(false);
			label_5.setVisible(false);
			textField_2.setVisible(true);
			textField_8.setVisible(true);
			textField_10.setVisible(false);
			textField_14.setVisible(false);
			textField_15.setVisible(false);
			textField_16.setVisible(false);
			comboBox_13.setVisible(true);
			comboBox_14.setVisible(true);
			comboBox_15.setVisible(false);
			comboBox_16.setVisible(false);
			comboBox_17.setVisible(false);
			comboBox_18.setVisible(false);
			comboBox_19.setVisible(true);
			comboBox_20.setVisible(true);
			comboBox_21.setVisible(false);
			comboBox_22.setVisible(false);
			comboBox_23.setVisible(false);
			comboBox_24.setVisible(false);
			formattedTextField_5.setVisible(true);
			formattedTextField_6.setVisible(false);
			formattedTextField_7.setVisible(false);
			formattedTextField_8.setVisible(false);
			formattedTextField_9.setVisible(false);
			formattedTextField_10.setVisible(true);
		}
		if (comboBox_12.getSelectedItem() == "3"){
			lblName.setVisible(true);
			lblAge.setVisible(true);
			lblRelationship.setVisible(true);
			lblSocialSecurityNumber_1.setVisible(true);
			label.setVisible(true);
			label_1.setVisible(true);
			label_2.setVisible(true);
			label_3.setVisible(false);
			label_4.setVisible(false);
			label_5.setVisible(false);
			textField_2.setVisible(true);
			textField_8.setVisible(true);
			textField_10.setVisible(true);
			textField_14.setVisible(false);
			textField_15.setVisible(false);
			textField_16.setVisible(false);
			comboBox_13.setVisible(true);
			comboBox_14.setVisible(true);
			comboBox_15.setVisible(true);
			comboBox_16.setVisible(false);
			comboBox_17.setVisible(false);
			comboBox_18.setVisible(false);
			comboBox_19.setVisible(true);
			comboBox_20.setVisible(true);
			comboBox_21.setVisible(true);
			comboBox_22.setVisible(false);
			comboBox_23.setVisible(false);
			comboBox_24.setVisible(false);
			formattedTextField_5.setVisible(true);
			formattedTextField_6.setVisible(true);
			formattedTextField_7.setVisible(false);
			formattedTextField_8.setVisible(false);
			formattedTextField_9.setVisible(false);
			formattedTextField_10.setVisible(true);
		}
		if (comboBox_12.getSelectedItem() == "4"){
			lblName.setVisible(true);
			lblAge.setVisible(true);
			lblRelationship.setVisible(true);
			lblSocialSecurityNumber_1.setVisible(true);
			label.setVisible(true);
			label_1.setVisible(true);
			label_2.setVisible(true);
			label_3.setVisible(true);
			label_4.setVisible(false);
			label_5.setVisible(false);
			textField_2.setVisible(true);
			textField_8.setVisible(true);
			textField_10.setVisible(true);
			textField_14.setVisible(true);
			textField_15.setVisible(false);
			textField_16.setVisible(false);
			comboBox_13.setVisible(true);
			comboBox_14.setVisible(true);
			comboBox_15.setVisible(true);
			comboBox_16.setVisible(true);
			comboBox_17.setVisible(false);
			comboBox_18.setVisible(false);
			comboBox_19.setVisible(true);
			comboBox_20.setVisible(true);
			comboBox_21.setVisible(true);
			comboBox_22.setVisible(true);
			comboBox_23.setVisible(false);
			comboBox_24.setVisible(false);
			formattedTextField_5.setVisible(true);
			formattedTextField_6.setVisible(true);
			formattedTextField_7.setVisible(true);
			formattedTextField_8.setVisible(false);
			formattedTextField_9.setVisible(false);
			formattedTextField_10.setVisible(true);
		}
		if (comboBox_12.getSelectedItem() == "5"){
			lblName.setVisible(true);
			lblAge.setVisible(true);
			lblRelationship.setVisible(true);
			lblSocialSecurityNumber_1.setVisible(true);
			label.setVisible(true);
			label_1.setVisible(true);
			label_2.setVisible(true);
			label_3.setVisible(true);
			label_4.setVisible(true);
			label_5.setVisible(false);
			textField_2.setVisible(true);
			textField_8.setVisible(true);
			textField_10.setVisible(true);
			textField_14.setVisible(true);
			textField_15.setVisible(true);
			textField_16.setVisible(false);
			comboBox_13.setVisible(true);
			comboBox_14.setVisible(true);
			comboBox_15.setVisible(true);
			comboBox_16.setVisible(true);
			comboBox_17.setVisible(true);
			comboBox_18.setVisible(false);
			comboBox_19.setVisible(true);
			comboBox_20.setVisible(true);
			comboBox_21.setVisible(true);
			comboBox_22.setVisible(true);
			comboBox_23.setVisible(true);
			comboBox_24.setVisible(false);
			formattedTextField_5.setVisible(true);
			formattedTextField_6.setVisible(true);
			formattedTextField_7.setVisible(true);
			formattedTextField_8.setVisible(true);
			formattedTextField_9.setVisible(false);
			formattedTextField_10.setVisible(true);
		}
		if (comboBox_12.getSelectedItem() == "6"){
			lblName.setVisible(true);
			lblAge.setVisible(true);
			lblRelationship.setVisible(true);
			lblSocialSecurityNumber_1.setVisible(true);
			label.setVisible(true);
			label_1.setVisible(true);
			label_2.setVisible(true);
			label_3.setVisible(true);
			label_4.setVisible(true);
			label_5.setVisible(true);
			textField_2.setVisible(true);
			textField_8.setVisible(true);
			textField_10.setVisible(true);
			textField_14.setVisible(true);
			textField_15.setVisible(true);
			textField_16.setVisible(true);
			comboBox_13.setVisible(true);
			comboBox_14.setVisible(true);
			comboBox_15.setVisible(true);
			comboBox_16.setVisible(true);
			comboBox_17.setVisible(true);
			comboBox_18.setVisible(true);
			comboBox_19.setVisible(true);
			comboBox_20.setVisible(true);
			comboBox_21.setVisible(true);
			comboBox_22.setVisible(true);
			comboBox_23.setVisible(true);
			comboBox_24.setVisible(true);
			formattedTextField_5.setVisible(true);
			formattedTextField_6.setVisible(true);
			formattedTextField_7.setVisible(true);
			formattedTextField_8.setVisible(true);
			formattedTextField_9.setVisible(true);
			formattedTextField_10.setVisible(true);
		}
	}
	
	protected void do_formattedTextField_4_focusLost(FocusEvent arg0) {
		netIncome();
	}
	protected void do_formattedTextField_11_focusLost(FocusEvent e) {
		netIncome();
	}
	protected void do_formattedTextField_12_focusLost(FocusEvent e) {
		netIncome();
	}
	protected void do_formattedTextField_13_focusLost(FocusEvent e) {
		netIncome();
	}
	protected void do_formattedTextField_14_focusLost(FocusEvent e) {
		netIncome();
	}
	protected void do_formattedTextField_15_focusLost(FocusEvent e) {
		netIncome();
	}
	protected void do_formattedTextField_16_focusLost(FocusEvent e) {
		netIncome();
	}
	protected void do_formattedTextField_17_focusLost(FocusEvent e) {
		netIncome();
	}
	protected void do_formattedTextField_18_focusLost(FocusEvent e) {
		netIncome();
	}
	protected void do_formattedTextField_19_focusLost(FocusEvent e) {
		netIncome();
	}
	protected void do_formattedTextField_20_focusLost(FocusEvent e) {
		netIncome();
	}
	protected void do_formattedTextField_21_focusLost(FocusEvent e) {
		netIncome();
	}
	protected void do_formattedTextField_22_focusLost(FocusEvent e) {
		netIncome();
	}
	protected void do_formattedTextField_26_focusLost(FocusEvent e) {
		netIncome();
	}
	protected void do_formattedTextField_29_focusLost(FocusEvent e) {
		netIncome();
	}
	protected void do_formattedTextField_23_focusLost(FocusEvent e) {
		netIncome();
	}
	protected void do_formattedTextField_25_focusLost(FocusEvent e) {
		netIncome();
	}
	protected void do_formattedTextField_24_focusLost(FocusEvent e) {
		netIncome();
	}
	protected void do_formattedTextField_27_focusLost(FocusEvent e) {
		netIncome();
	}
	protected void do_formattedTextField_28_focusLost(FocusEvent e) {
		netIncome();
	}
	
	public void netIncome(){
		int x = 0;
		int y = 0;
		int z = x - y;
		x += Integer.parseInt(formattedTextField_4.getText().replace("," , "").replace("$" , "").replace(".00", ""));
		x += Integer.parseInt(formattedTextField_11.getText().replace("," , "").replace("$" , "").replace(".00", ""));
		x += Integer.parseInt(formattedTextField_12.getText().replace("," , "").replace("$" , "").replace(".00", ""));
		x += Integer.parseInt(formattedTextField_13.getText().replace("," , "").replace("$" , "").replace(".00", ""));
		x += Integer.parseInt(formattedTextField_14.getText().replace("," , "").replace("$" , "").replace(".00", ""));
		x += Integer.parseInt(formattedTextField_15.getText().replace("," , "").replace("$" , "").replace(".00", ""));
		x += Integer.parseInt(formattedTextField_16.getText().replace("," , "").replace("$" , "").replace(".00", ""));
		x += Integer.parseInt(formattedTextField_17.getText().replace("," , "").replace("$" , "").replace(".00", ""));
		x += Integer.parseInt(formattedTextField_18.getText().replace("," , "").replace("$" , "").replace(".00", ""));
		x += Integer.parseInt(formattedTextField_19.getText().replace("," , "").replace("$" , "").replace(".00", ""));
		y += Integer.parseInt(formattedTextField_20.getText().replace("," , "").replace("$" , "").replace(".00", ""));
		y += Integer.parseInt(formattedTextField_21.getText().replace("," , "").replace("$" , "").replace(".00", ""));
		y += Integer.parseInt(formattedTextField_22.getText().replace("," , "").replace("$" , "").replace(".00", ""));
		y += Integer.parseInt(formattedTextField_23.getText().replace("," , "").replace("$" , "").replace(".00", ""));
		y += Integer.parseInt(formattedTextField_24.getText().replace("," , "").replace("$" , "").replace(".00", ""));
		y += Integer.parseInt(formattedTextField_25.getText().replace("," , "").replace("$" , "").replace(".00", ""));
		y += Integer.parseInt(formattedTextField_26.getText().replace("," , "").replace("$" , "").replace(".00", ""));
		y += Integer.parseInt(formattedTextField_27.getText().replace("," , "").replace("$" , "").replace(".00", ""));
		y += Integer.parseInt(formattedTextField_28.getText().replace("," , "").replace("$" , "").replace(".00", ""));
		y += Integer.parseInt(formattedTextField_29.getText().replace("," , "").replace("$" , "").replace(".00", ""));
		z = x - y;
		if (z >= 0){
			label_8.setForeground(Color.black);
		} else {
			label_8.setForeground(Color.red);
		}
		label_6.setText("$" + Integer.toString(x) + ".00");
		label_7.setText("$" + Integer.toString(y) + ".00");
		String temp = Integer.toString(z);
		if (temp.length() > 4){
		label_8.setText("$" + temp.substring(0, temp.length()-3) + "," + temp.substring(temp.length() - 3, temp.length()) + ".00");
		} else {
			label_8.setText("$" + temp + ".00");
		}
	}
	protected void do_mntmExit_actionPerformed(ActionEvent arg0) {
		this.dispose();
	}
	protected void do_mntmStartNewApplication_actionPerformed(ActionEvent e) {
		main(null);
	}
	protected void do_mntmPersonal_actionPerformed(ActionEvent e) {
		helpPersonal personal = new helpPersonal();
		personal.setVisible(true);
	}
	protected void do_mntmHousehold_actionPerformed(ActionEvent e) {
		helpHousehold household = new helpHousehold();
		household.setVisible(true);
	}
	protected void do_mntmFinancial_actionPerformed(ActionEvent e) {
		helpFinancial financial = new helpFinancial();
		financial.setVisible(true);
	}
}
