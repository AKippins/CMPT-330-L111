import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;
import javax.swing.JScrollPane;


public class AaronKippins extends JFrame {

	private JPanel contentPane;
	private final JLabel lblKippinsPizzaria = new JLabel("Kippins' Pizzaria");
	private final JTextField nameTextField = new JTextField();
	private final JLabel lblName = new JLabel("Name:");
	private final JLabel lblSize = new JLabel("Size:");
	private final JComboBox comboBox = new JComboBox();
	private final JTextArea orderTextArea = new JTextArea();
	private final JButton btnPlaceOrder = new JButton("Place Order");
	private final JLabel lblToppings = new JLabel("Toppings:");
	private final JList list = new JList();
	private final JScrollPane scrollPane = new JScrollPane();
	private final JScrollPane scrollPane_1 = new JScrollPane();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AaronKippins frame = new AaronKippins();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AaronKippins() {
		nameTextField.setBounds(79, 77, 112, 20);
		nameTextField.setColumns(10);
		jbInit();
	}
	private void jbInit() {
		setTitle("Aaron Kippins");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblKippinsPizzaria.setForeground(Color.BLUE);
		lblKippinsPizzaria.setFont(new Font("Magneto", Font.PLAIN, 25));
		lblKippinsPizzaria.setBounds(93, 27, 242, 29);
		
		contentPane.add(lblKippinsPizzaria);
		
		contentPane.add(nameTextField);
		lblName.setBounds(20, 80, 46, 14);
		
		contentPane.add(lblName);
		lblSize.setBounds(20, 105, 46, 14);
		
		contentPane.add(lblSize);
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Extra Large", "Large", "Medium", "Small", "Individual"}));
		comboBox.setBounds(79, 102, 112, 20);
		
		contentPane.add(comboBox);
		scrollPane_1.setBounds(211, 77, 202, 116);
		
		contentPane.add(scrollPane_1);
		scrollPane_1.setViewportView(orderTextArea);
		btnPlaceOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_btnPlaceOrder_actionPerformed(e);
			}
		});
		btnPlaceOrder.setBounds(162, 227, 112, 23);
		
		contentPane.add(btnPlaceOrder);
		lblToppings.setBounds(20, 130, 63, 14);
		
		contentPane.add(lblToppings);
		scrollPane.setBounds(79, 128, 112, 65);
		
		contentPane.add(scrollPane);
		scrollPane.setViewportView(list);
		list.setModel(new AbstractListModel() {
			String[] values = new String[] {"Pepperoni", "Sausage", "Bacon", "Ham", "Meatballs", "Onions", "Mushrooms", "Canadian Bacon", "Pineapple", "Chicken"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
	}
	protected void do_btnPlaceOrder_actionPerformed(ActionEvent e) {
		orderTextArea.append("Hello, " + nameTextField.getText() + ".\nYou ordered a(n) \n" + comboBox.getSelectedItem().toString() + " pizza\n" + "Your selected toppings are:\n" /*+ list.getSelectedValuesList().toString()*/);
		Object[] items = list.getSelectedValues();
		for(int x = 0; x < items.length; x++){
			orderTextArea.append(items[x].toString() + "\n");
		}
	}
}
