import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;
import javax.swing.KeyStroke;
import java.awt.event.KeyEvent;
import java.awt.event.InputEvent;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.ButtonGroup;


public class Menu extends JFrame {

	private JPanel contentPane;
	private final JMenuBar menuBar = new JMenuBar();
	private final JMenu mnFile = new JMenu("File");
	private final JMenuItem mntmOpenFile = new JMenuItem("Open File...");
	private final JMenu mnNew = new JMenu("New");
	private final JSeparator separator = new JSeparator();
	private final JMenuItem mntmClose = new JMenuItem("Close");
	private final JMenuItem mntmFirstOption = new JMenuItem("First Option");
	private final JMenuItem mntmSecondOption = new JMenuItem("Second Option");
	private final JLabel lblMenuChoice = new JLabel("Menu Choice");
	private final JMenu mnEdit = new JMenu("Edit");
	private final JMenuItem mntmUndo = new JMenuItem("Undo");
	private final JMenuItem mntmRedo = new JMenuItem("Redo");
	private final JSeparator separator_1 = new JSeparator();
	private final JMenuItem mntmCut = new JMenuItem("Cut");
	private final JMenuItem mntmCopy = new JMenuItem("Copy");
	private final JSeparator separator_2 = new JSeparator();
	private final JMenuItem mntmPaste = new JMenuItem("Paste");
	private final JRadioButtonMenuItem rdbtnmntmTest = new JRadioButtonMenuItem("Test 1");
	private final JCheckBoxMenuItem chckbxmntmTest = new JCheckBoxMenuItem("Test 2");
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final JMenuItem mntmExit = new JMenuItem("Exit");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menu frame = new Menu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Menu() {
		jbInit();
	}
	private void jbInit() {
		setTitle("Aaron Kippins Menu Stuff");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		setJMenuBar(menuBar);
		
		menuBar.add(mnFile);
		
		mnFile.add(mnNew);
		mntmFirstOption.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmFirstOption_actionPerformed(e);
			}
		});
		
		mnNew.add(mntmFirstOption);
		mntmSecondOption.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmSecondOption_actionPerformed(e);
			}
		});
		
		mnNew.add(mntmSecondOption);
		
		mnFile.add(mntmOpenFile);
		
		mnFile.add(separator);
		mntmClose.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W, InputEvent.CTRL_MASK));
		
		mnFile.add(mntmClose);
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmExit_actionPerformed(e);
			}
		});
		
		mnFile.add(mntmExit);
		
		menuBar.add(mnEdit);
		mntmUndo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z, InputEvent.CTRL_MASK));
		
		mnEdit.add(mntmUndo);
		mntmRedo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Y, InputEvent.CTRL_MASK));
		
		mnEdit.add(mntmRedo);
		
		mnEdit.add(separator_1);
		mntmCut.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, InputEvent.CTRL_MASK));
		
		mnEdit.add(mntmCut);
		mntmCopy.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, InputEvent.CTRL_MASK));
		
		mnEdit.add(mntmCopy);
		
		mnEdit.add(separator_2);
		mntmPaste.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V, InputEvent.CTRL_MASK));
		
		mnEdit.add(mntmPaste);
		buttonGroup.add(rdbtnmntmTest);
		rdbtnmntmTest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnmntmTest_actionPerformed(e);
			}
		});
		
		mnEdit.add(rdbtnmntmTest);
		chckbxmntmTest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxmntmTest_actionPerformed(e);
			}
		});
		
		mnEdit.add(chckbxmntmTest);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblMenuChoice.setBounds(171, 112, 87, 14);
		
		contentPane.add(lblMenuChoice);
	}
	protected void do_mntmFirstOption_actionPerformed(ActionEvent e) {
		lblMenuChoice.setText(mntmFirstOption.getText());
	}
	protected void do_mntmSecondOption_actionPerformed(ActionEvent e) {
		lblMenuChoice.setText(mntmSecondOption.getText());
	}
	protected void do_rdbtnmntmTest_actionPerformed(ActionEvent e) {
		rdbtnmntmTest.setText("Don't Make Me Do Stuff");
	}
	protected void do_chckbxmntmTest_actionPerformed(ActionEvent e) {
		if (chckbxmntmTest.isSelected()){
		chckbxmntmTest.setText("Please Unselect Me");
		} else {
			chckbxmntmTest.setText("Test 2");
		}
	}
	protected void do_mntmExit_actionPerformed(ActionEvent e) {
		System.exit(EXIT_ON_CLOSE);
	}
}
