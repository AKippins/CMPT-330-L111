import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JSlider;
import java.awt.Color;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.JButton;

//Be Able to explain progress bar and toggle button
public class Groups extends JFrame {

	private JPanel contentPane;
	private final JRadioButton rdbtnOne = new JRadioButton("One");
	private final JRadioButton rdbtnTwo = new JRadioButton("Two");
	private final JRadioButton rdbtnThree = new JRadioButton("Three");
	private final JRadioButton rdbtnFour = new JRadioButton("Four");
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final JCheckBox chckbxFirst = new JCheckBox("First");
	private final JCheckBox chckbxSecond = new JCheckBox("Second");
	private final JCheckBox chckbxThird = new JCheckBox("Third");
	private final JLabel lblRadioChoice = new JLabel("Radio Choice:");
	private final JLabel lblCheckboxChoices = new JLabel("Checkbox Choice(s):");
	private final JSlider slider = new JSlider();
	private final JLabel lblSliderValue = new JLabel("0");
	private final JSpinner spinner = new JSpinner();
	private final JLabel lblSpinnerValue = new JLabel("Spinner Value: ");
	private final JTextField goToSlider = new JTextField();
	private final JButton btnGo = new JButton("Go!");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Groups frame = new Groups();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Groups() {
		goToSlider.setBounds(46, 166, 86, 20);
		goToSlider.setColumns(10);
		jbInit();
	}
	private void jbInit() {
		setTitle("Aaron Kippins");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		buttonGroup.add(rdbtnOne);
		rdbtnOne.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnOne_actionPerformed(e);
			}
		});
		rdbtnOne.setBounds(36, 60, 109, 23);
		
		contentPane.add(rdbtnOne);
		buttonGroup.add(rdbtnTwo);
		rdbtnTwo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnTwo_actionPerformed(e);
			}
		});
		rdbtnTwo.setBounds(36, 86, 109, 23);
		
		contentPane.add(rdbtnTwo);
		buttonGroup.add(rdbtnThree);
		rdbtnThree.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnThree_actionPerformed(e);
			}
		});
		rdbtnThree.setBounds(36, 112, 109, 23);
		
		contentPane.add(rdbtnThree);
		buttonGroup.add(rdbtnFour);
		rdbtnFour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_rdbtnFour_actionPerformed(e);
			}
		});
		rdbtnFour.setBounds(36, 136, 109, 23);
		
		contentPane.add(rdbtnFour);
		chckbxFirst.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxFirst_actionPerformed(e);
			}
		});
		chckbxFirst.setBounds(181, 60, 97, 23);
		
		contentPane.add(chckbxFirst);
		chckbxSecond.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxSecond_actionPerformed(e);
			}
		});
		chckbxSecond.setBounds(181, 86, 97, 23);
		
		contentPane.add(chckbxSecond);
		chckbxThird.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_chckbxThird_actionPerformed(e);
			}
		});
		chckbxThird.setBounds(181, 112, 97, 23);
		
		contentPane.add(chckbxThird);
		lblRadioChoice.setBounds(36, 39, 135, 14);
		
		contentPane.add(lblRadioChoice);
		lblCheckboxChoices.setBounds(181, 39, 243, 14);
		
		contentPane.add(lblCheckboxChoices);
		slider.setValue(0);
		slider.setMaximum(150);
		slider.setMinimum(-150);
		slider.setSnapToTicks(true);
		slider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				do_slider_stateChanged(arg0);
			}
		});
		slider.setPaintTicks(true);
		slider.setPaintLabels(true);
		slider.setMinorTickSpacing(15);
		slider.setMajorTickSpacing(30);
		slider.setBounds(10, 197, 228, 53);
		
		contentPane.add(slider);
		lblSliderValue.setBounds(248, 209, 46, 14);
		
		contentPane.add(lblSliderValue);
		spinner.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				do_spinner_stateChanged(e);
			}
		});
		spinner.setBounds(263, 178, 46, 20);
		
		contentPane.add(spinner);
		lblSpinnerValue.setBounds(319, 181, 105, 14);
		
		contentPane.add(lblSpinnerValue);
		
		contentPane.add(goToSlider);
		btnGo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_btnGo_actionPerformed(arg0);
			}
		});
		btnGo.setBounds(142, 165, 89, 23);
		
		contentPane.add(btnGo);
	}
	
	protected void do_chckbxFirst_actionPerformed(ActionEvent e) {
		checkbox_update();
	}
	protected void do_chckbxSecond_actionPerformed(ActionEvent e) {
		checkbox_update();
	}
	protected void do_chckbxThird_actionPerformed(ActionEvent e) {
		checkbox_update();
	}
	protected void do_rdbtnOne_actionPerformed(ActionEvent e) {
		lblRadioChoice.setText("Radio Choice: One");
		slider.setValue(slider.getMaximum()/4);
	}
	protected void do_rdbtnTwo_actionPerformed(ActionEvent e) {
		lblRadioChoice.setText("Radio Choice: Two");
		slider.setValue(slider.getMaximum()/2);
	}
	protected void do_rdbtnThree_actionPerformed(ActionEvent e) {
		lblRadioChoice.setText("Radio Choice: Three");
		slider.setValue(slider.getMaximum()/4 * 3);
	}
	protected void do_rdbtnFour_actionPerformed(ActionEvent e) {
		lblRadioChoice.setText("Radio Choice: Four");
		slider.setValue(slider.getMaximum());
	}
	
	private void checkbox_update() {
		String output= "";
		if (chckbxFirst.isSelected()){
			output = "First ";
		}
		if (chckbxSecond.isSelected()){
			output += "Second ";
		}
		if (chckbxThird.isSelected()){
			output += "Third ";
		}
		lblCheckboxChoices.setText("Checkbox Choice(s): " + output);
	}
	protected void do_slider_stateChanged(ChangeEvent arg0) {
		lblSliderValue.setText(Integer.toString(slider.getValue()));
	}
	protected void do_spinner_stateChanged(ChangeEvent e) {
		lblSpinnerValue.setText("Spinner Value: " + spinner.getValue());
	}
	protected void do_btnGo_actionPerformed(ActionEvent arg0) {
		slider.setValue(Integer.parseInt(goToSlider.getText()));
	}
}

